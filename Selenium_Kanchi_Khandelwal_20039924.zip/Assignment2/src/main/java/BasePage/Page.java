package BasePage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import Listeners.Listeners;

public class Page {
	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static WebDriverWait wait;
	public static JavascriptExecutor je;
	
	public Page() {

		try {
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/properties/OR.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			OR.load(fis);
			log.debug("OR file loaded !!!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		

	}
	public void selectDriver(WebDriver driver , String browser)
	{		
		this.driver = driver;
		log.debug("Browser selected:" + browser);
	}
	
	public void correctURL(String URL)
	{
		Assert.assertEquals(driver.getCurrentUrl(), URL);
		log.debug("correctURL selected: " + URL );
		
	}
	
	public static void hold()
	{
		wait = new WebDriverWait(driver,1000);
	}
	
	public static void click(String locator) {
		
		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_XPATH")) {
			System.out.println("in xpath");
			driver.findElement(By.xpath(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_ID")) {
			System.out.println("Id");
			driver.findElement(By.id(OR.getProperty(locator))).click();
		}
		log.debug("Clicking on an Element : " + locator);
		Listeners.testReport.get().log(Status.INFO, "Clicking on : " + locator);
	}
	
	public boolean isElementPresent(String locator) {

		try {	
			if (locator.endsWith("_CSS")) {
				 driver.findElement(By.cssSelector(OR.getProperty(locator)));
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator)));
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator)));
			}
			
			log.debug("Element found : " + locator);
			Listeners.testReport.get().log(Status.INFO, "Element filled : " + locator );
			return true;

		} catch (NoSuchElementException e) {

			return false;
		}
		
	}
	
	public static String gettext(String locator) {
		String text = null;
		if (locator.endsWith("_CSS")) {
			text = driver.findElement(By.cssSelector(OR.getProperty(locator))).getText();
		} else if (locator.endsWith("_XPATH")) {
			text = driver.findElement(By.xpath(OR.getProperty(locator))).getText();
		} else if (locator.endsWith("_ID")) {
			text = driver.findElement(By.id(OR.getProperty(locator))).getText();
		}
		log.debug("Getting text of an element :" + locator);
		Listeners.testReport.get().log(Status.INFO, "Getting text of : " + locator);
		return text;

	}

	public static void type(String locator, String value) {

		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locator))).sendKeys(value);
		} else if (locator.endsWith("_XPATH")) {
			driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
		} else if (locator.endsWith("_ID")) {
			driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);
		}

		log.debug("Typing in an Element : " + locator + " entered value as : " + value);
		Listeners.testReport.get().log(Status.INFO, "Typing in : " + locator + " entered value as " + value);

	}
	
	public void elementscroll(String locator)
	{
		je = (JavascriptExecutor) driver;
		WebElement retrn = null;
		if (locator.endsWith("_CSS")) {
			retrn = driver.findElement(By.cssSelector(OR.getProperty(locator)));
		} else if (locator.endsWith("_XPATH")) {
			retrn = driver.findElement(By.xpath(OR.getProperty(locator)));
		} else if (locator.endsWith("_ID")) {
			retrn = driver.findElement(By.id(OR.getProperty(locator)));
		}
		je.executeScript("arguments[0].scrollIntoView(true);", retrn );
		log.info("scrolling to locate element");
		Listeners.testReport.get().log(Status.INFO, "Scrolling to locate element : " + locator);
	}
	
	public void SelectByText(String locator , String value)
	{
		WebElement retrn = null;
		if (locator.endsWith("_CSS")) {
			retrn = driver.findElement(By.cssSelector(OR.getProperty(locator)));
		} else if (locator.endsWith("_XPATH")) {
			retrn = driver.findElement(By.xpath(OR.getProperty(locator)));
		} else if (locator.endsWith("_ID")) {
			retrn = driver.findElement(By.id(OR.getProperty(locator)));
		}
		Select select = new Select(retrn);
		select.selectByVisibleText(value);
		log.info("selecting the value :" + value);
		Listeners.testReport.get().log(Status.INFO, "selecting the value :" + value + "from :" + locator);
	}


}
