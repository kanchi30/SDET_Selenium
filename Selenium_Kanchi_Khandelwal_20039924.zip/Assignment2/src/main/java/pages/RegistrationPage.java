package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import Listeners.Listeners;

public class RegistrationPage extends BasePage.Page {

	public void SelectUrl(String URL)
	{
			driver.get(URL);
			correctURL(URL);
			click("Register_XPATH");
	}

	public void GenderSelection(String gender)
	{
			if(gender.equals("F"))
			{	
				if(isElementPresent("GenderFemale_ID"))
				click("GenderFemale_ID");
			
			}
			else if (gender.equals("M"))
			{
				if(isElementPresent("GenderMale_ID"))
				click("GenderMale_ID");	
			}
	}
	
	public void FirstName(String Fname)
	{
				if(isElementPresent("FirstName_ID"))
				{
					type("FirstName_ID" , Fname);
					
				}
}

	public void LastName(String Lname)
	{
				if(isElementPresent("LastName_ID"))
				{
					type("LastName_ID" , Lname);
					
				}
	}
	
	public void Email(String Email)
	{
				if(isElementPresent("Email_XPATH"))
				{
					type("Email_XPATH" , Email);
					
				}
	}
	
	public void Password(String password , String confirmPassword)
	{
		if(password.equals(confirmPassword))
		{
			if(isElementPresent(""))
			{
				type("Password_XPATH" , password);
				type("ConfirmPassword_XPATH" , confirmPassword);			
			}
		}
		else
		{
			log.debug("Password is not equal to reconfirm password");
			Assert.fail("Password doesnot match with reconfirm password");
		}
	}
	
	public void Birthdate(String Day , String Month , String Year)
	{
		if(isElementPresent("Date_XPATH"))
		{
			elementscroll("Date_XPATH");
			SelectByText("Date_XPATH" , Day);
			elementscroll("Month_XPATH");
			SelectByText("Month_XPATH" , Month);
			elementscroll("Year_XPATH");
			SelectByText("Year_XPATH" , Year);
		}
		else if (isElementPresent("Date_ID"))
				{
				elementscroll("Date_ID");
				SelectByText("Date_ID" , Day);
				elementscroll("Month_ID");
				SelectByText("Month_ID" , Month);
				elementscroll("Year_ID");
				SelectByText("Year_ID" , Year);
				}
	}
	
	public void CountrySelection(String country)
	{
		if(isElementPresent("Country_XPATH"))
		{
			elementscroll("Country_XPATH");
			SelectByText("Country_XPATH" , country);
		}
	}

	public void Address(String House , String Location)
	{
		if(isElementPresent("House_XPATH"))
		{
			type("House_XPATH" , House);
			type("Address_XPATH", Location);
			click("Terms_ID");
		}
	}
	
	public void registerButton()
	{
		elementscroll("Register_ID");
		click("Register_ID");
	}
	
	public boolean TitleCheck()
	{
		String title = driver.getTitle();
		System.out.println(title);
		if(title.equalsIgnoreCase("Crear perfil, gracias"))
		{
			log.debug("Register Success");
			Listeners.testReport.get().log(Status.INFO, "Register Successful");
			return true;
		}
		
		else if(title.equalsIgnoreCase("Profil anlegen Danke"))
		{
			log.debug("Register Success");
			Listeners.testReport.get().log(Status.INFO, "Register Successful");
			return true;
		}
		else if (title.equalsIgnoreCase("Optional Field Page"))
		{
			log.debug("Register Success");
			Listeners.testReport.get().log(Status.INFO,"Register Successful");
			return true;
		}
		else
		{
			log.debug("Register not successful");
			Listeners.testReport.get().log(Status.INFO, "Register not Successful");
			return false;
		}
		
	}
	
	public boolean AccountCheck()
	{
		if(isElementPresent("ErrorAccount_XPATH"))
		{
		WebElement error = driver.findElement(By.xpath(OR.getProperty("ErrorAccount_XPATH")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty("ErrorAccount_XPATH"))));
		String title = error.getText();
		System.out.println(title);
		if(title.contains("Direcci�n de correo electr�nico ya est� en uso."))
		{
			log.debug("Account already Exists");
			Listeners.testReport.get().log(Status.INFO, "Account already Exists");
			return true;
		}
		
		else if(title.contains("Wir haben unter dieser Email bereits einen Account f�r Sie bei P&G, z.B. weil Sie sich �ber eine andere P&G Marken- oder Programm-Webseite registriert haben. Bitte geben Sie Ihr Passwort ein."))
		{
			log.debug("Account already Exists");
			Listeners.testReport.get().log(Status.INFO, "Account already Exists");
			return true;
		}
		else if (title.contains("An account with this email address already exists."))
		{
			log.debug("Account already Exists");
			Listeners.testReport.get().log(Status.INFO, "Account already Exists");
			return true;
		}
		else
			return false;
		}
		else
			return false;	
	}
	
	public boolean PasswordCheck()
	{
		if(isElementPresent("ErrorAccount_XPATH"))
		{
		WebElement error = driver.findElement(By.xpath(OR.getProperty("ErrorAccount_XPATH")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty("ErrorAccount_XPATH"))));
		String title = error.getText();
		System.out.println(title);
		if(title.contains("La contrase�a debe tener un m�nimo de 8 caracteres, incluyendo al menos 1 letra y 1 n�mero."))
		{
			log.debug("Password Not upto standars");
			Listeners.testReport.get().log(Status.INFO, "Password Not upto standars");
			return true;
		}
		else if(title.contains("Ihr Kennwort muss"))
		{
			log.debug("Password Not upto standars");
			Listeners.testReport.get().log(Status.INFO, "Password Not upto standars");
			return true;
		}
		else if (title.contains("minimum 8 characters"))
		{
			log.debug("Password Not upto standars");
			Listeners.testReport.get().log(Status.INFO, "Password Not upto standars");
			return true;
		}
		else
		{
			log.debug("Password upto standars");
			Listeners.testReport.get().log(Status.INFO, "Password upto standars");
			return false;
		}	
		}
		else
			return false;
	}
	
	public boolean EmailCheck()
	{
		if(isElementPresent("ErrorAccount_XPATH"))
		{
		WebElement error = driver.findElement(By.xpath(OR.getProperty("ErrorEmail_XPATH")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty("ErrorEmail_XPATH"))));
		String title = error.getText();
		System.out.println(title);
		if(title.contains("La contrase�a debe tener un m�nimo de 8 caracteres, incluyendo al menos 1 letra y 1 n�mero."))
		{
			log.debug("Email address not valid");
			Listeners.testReport.get().log(Status.INFO, "Email address not valid");
			return true;
		}
		else if(title.contains("Ihr Kennwort muss"))
		{
			log.debug("Email address not valid");
			Listeners.testReport.get().log(Status.INFO, "Email address not valid");
			return true;
		}
		else if (title.contains("minimum 8 characters"))
		{
			log.debug("Email address not valid");
			Listeners.testReport.get().log(Status.INFO, "Email address not valid");
			return true;
		}
		else
		{
				log.debug("Email address not valid");
				Listeners.testReport.get().log(Status.INFO, "Email address valid");
				return false; 
		}
		}
		else
			return false;
		}
}