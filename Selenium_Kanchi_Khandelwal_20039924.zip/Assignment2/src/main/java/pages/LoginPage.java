package pages;

import com.aventstack.extentreports.Status;

import BasePage.Page;
import Listeners.Listeners;

public class LoginPage extends Page {

	public void SelectUrl(String URL)
	{
			driver.get(URL);
			correctURL(URL);
			click("Login_XPATH");
	}
	
	public boolean TitleCheck()
	{
		String title = driver.getTitle();
		System.out.println(title);
		if(title.equalsIgnoreCase("Anmelden"))
		return true;
		else if(title.equalsIgnoreCase("Login"))
			return true;
		else if (title.equalsIgnoreCase("Inicia sesi�n en tu cuenta"))
			return true;
		else
			return false;
		
	}
	
	public boolean LoginCheck()
	{
		String title = driver.getTitle();
		System.out.println(title);
		if(title.equalsIgnoreCase("Ver Perfil"))
		{
			log.debug("Login Success");
			Listeners.testReport.get().log(Status.INFO, "Login Successful");
			return true;}
		else if(title.equalsIgnoreCase("ViewProfilePage"))
			{
			log.debug("Login Success");
			Listeners.testReport.get().log(Status.INFO, "Login Successful");
			return true;
			}
		else if (title.equalsIgnoreCase("View Profile"))
			{
			log.debug("Login Success");
			Listeners.testReport.get().log(Status.INFO, "Login Successful");
			return true;
			}
		else
			return false;
		
	}
	
	public void EmailEnter(String Email)
	{
				if(isElementPresent("LoginUsername_XPATH"))
				{
					type("LoginUsername_XPATH" , Email);				
				}
	}
	
	public void PasswordEnter(String password)
	{
				if(isElementPresent("LoginPassword_XPATH"))
				{
					type("LoginPassword_XPATH" , password);				
				}
	}
	
	public void LoginButton()
	{
		click("LoginButton_XPATH");
	}
	
	public boolean PasswordCheck()
	{
		if(isElementPresent("PasswordIncorrect_XPATH"))
		{
		String title = gettext("PasswordIncorrect_XPATH");
		System.out.println(title);
		if(title.contains("La combinaci�n de correo"))
		{
			log.debug("Password Not correct");
			Listeners.testReport.get().log(Status.INFO, "Password Not correct");
			return false;
		}
		else if(title.contains("Die eingegebene Kombination"))
		{
			log.debug("Password Not correct");
			Listeners.testReport.get().log(Status.INFO, "Password Not correct");
			return false;
		}
		else if (title.contains("The email and password"))
		{
			log.debug("Password Not correct");
			Listeners.testReport.get().log(Status.INFO, "Password Not correct");
			return false;
		}
		else
		{
			log.debug("Password correct");
			Listeners.testReport.get().log(Status.INFO, "Password correct");
			return true;
		}	
	}
		else
			return true;
	}

	public void ForgetPasswordClick()
	{
		click("ForgetPassword_XPATH");
	}
	 
	public void ResetButton(String Email)
	{
		if(isElementPresent("EmailAddressLogin_XPATH"))
		{
			elementscroll("EmailAddressLogin_XPATH");
			type("EmailAddressLogin_XPATH" , Email);
			elementscroll("Reset1_XPATH");
			click("Reset1_XPATH");
		}
		else
			click("Reset2_XPATH");
		}
	
	public boolean ResetCheck()
	{
		String title = gettext("Reset_ID");
		System.out.println(title);
		if(title.equalsIgnoreCase("Recibir� un correo"))
		{
			log.debug("Reset Success");
			Listeners.testReport.get().log(Status.INFO, "Reset Successful");
			return true;
		}
		
		else if(title.contains("Sie erhalten in K�rze"))
		{
			log.debug("Reset Success");
			Listeners.testReport.get().log(Status.INFO, "Reset Successful");
			return true;
		}
		else if (title.contains("We have sent an email"))
		{
			log.debug("Reset Success");
			Listeners.testReport.get().log(Status.INFO,"Reset Successful");
			return true;
		}
		else
		{
			log.debug("Reset not successful");
			Listeners.testReport.get().log(Status.INFO, "Reset not Successful");
			return false;
		}
		
	}
}

