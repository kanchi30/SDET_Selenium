//Login Functionality
package assignment_2;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.LoginPage;


public class LoginSuccess extends Initialization {
	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "Login");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Login(String URL,String Email,String password) throws InterruptedException {
	
		LoginPage login = new LoginPage();
		login.SelectUrl(URL);
		
		Assert.assertTrue(login.TitleCheck());
		
		login.EmailEnter(Email);
		login.PasswordEnter(password);
		login.LoginButton();
		boolean value = true;
		
		value = login.PasswordCheck();
		if(value)
		Assert.assertTrue(login.LoginCheck());
	}
	
}
