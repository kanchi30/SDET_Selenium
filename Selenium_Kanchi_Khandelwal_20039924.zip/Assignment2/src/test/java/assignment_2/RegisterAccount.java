package assignment_2;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BasePage.Page;
import pages.RegistrationPage;


public class RegisterAccount extends Initialization {
	
	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "Registration");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Registration_Account(String URL,String Email,String password,String ConPassword,String Day,String Month,String Year,String Fname,String Lname,String gender,String Country,String House,String Location) {
	
		RegistrationPage register = new RegistrationPage();
		register.SelectUrl(URL);
		
		Page.hold();
		
			//Gender selection
			register.GenderSelection(gender);
			//FirstName
			register.FirstName(Fname);
			//LastName
			register.LastName(Lname);
		
			//Email
			register.Email(Email);
		
			//Password and reconfirm password
			register.Password(password, ConPassword);
				
			//Birthdate Selection
			register.Birthdate(Day, Month, Year);
			
			//Selection of country
			register.CountrySelection(Country);
			
			//House address & Location
			register.Address(House, Location);	
		
			//Register click
			register.registerButton();
			
			boolean value = true ;
			value = register.AccountCheck();
			value = register.EmailCheck();
			value = register.AccountCheck();
			
			if(value)
			Assert.assertTrue(register.TitleCheck());
		
	}
	
}
