package assignment_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import BasePage.Page;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Initialization {

	public static WebDriver driver;
	public static SoftAssert softassert = new SoftAssert();
	
	public static void SelectBrowser(String browser)
	{
		
		if(browser.equalsIgnoreCase("Chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("FireFox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver= new FirefoxDriver();
		}
	}
	@BeforeTest
	@Parameters({"browser"})
	
	public static void OpenBrowser(String browser)
	{
		//String name = "Chrome";
		//System.out.println("BrowserName: "+ browser);
		SelectBrowser(browser);
		Page homePage = new Page();
		homePage.selectDriver(driver,browser);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
	}
	
	@AfterTest
	public static void CloseBrowser()
	{
		//Browser closing
		driver.quit();
	}
}
