package pages;

import java.text.DateFormatSymbols;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import basePage.Base;

public class FormPage extends Base {

	public void SelectURL() {
		driver.get("https://demoqa.com/automation-practice-form");
	}

	public void FirstName(String Fname) {
		type("FirstName_XPATH", Fname);
	}

	public void LastName(String Lname) {
		type("LastName_XPATH", Lname);
	}

	public void Mobile(String mobile) {
		type("Mobile_XPATH", mobile);
	}

	public void Address(String address) {
		type("Address_XPATH", address);
	}

	public void Subject(String[] subjects) throws InterruptedException {
		click("SubjectClick_XPATH");
		Thread.sleep(2000);
		for (int i = 0; i < subjects.length; i++) {

			System.out.println(subjects[i]);
			type("SubjectEnter_XPATH", subjects[i]);
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OR.getProperty("SubjectEnter_XPATH"))));
			driver.findElement(By.xpath(OR.getProperty("SubjectEnter_XPATH"))).sendKeys(Keys.ENTER);
		}
	}

	public void Gender(String gender) {
		if (gender.equals("Male"))
			click("RadioMale_XPATH");

		else if (gender.equals("Female"))
			click("RadioFemale_XPATH");

		else if (gender.equals("Other"))
			click("RadioOthers_XPATH");
	}

	public void Hobbies(String[] hobbies) {
		
		for (int i = 0; i < hobbies.length; i++) {

			if (hobbies[i].equals("Sports"))
				click("Hobby1_XPATH");
			else if (hobbies[i].equals("Reading"))
				click("Hobby2_XPATH");
			else if (hobbies[i].equals("Music"))
				click("Hobby3_XPATH");
		}
	}
	
	public void Email(String mobile) {
		type("Email_XPATH", mobile);
	}
	
	public void State(String state)
	{
		type("State_XPATH" , state);
		driver.findElement(By.xpath(OR.getProperty("State_XPATH"))).sendKeys(Keys.ENTER);
	}
	
	public void City(String city)
	{
		click("CityClick_XPATH");
		type("City_XPATH" , city);
		driver.findElement(By.xpath(OR.getProperty("City_XPATH"))).sendKeys(Keys.ENTER);
	}
	
	public void picture(String picture)
	{
		type("Picture_XPATH" , picture);
	}
	
	
	public static	String getMonthForInt(int m) {
		m = m- 1 ; 
	    String month = "invalid";
	    DateFormatSymbols dfs = new DateFormatSymbols();
	    String[] months = dfs.getMonths();
	    if (m >= 0 && m <= 11 ) {
	        month = months[m];
	    }
	    return month;
	}

	public void selectBirthdate(String Month , String year, String day) throws InterruptedException {
		String month =  getMonthForInt(Integer.parseInt(Month)) ;
		click("Calender_XPATH");
		Thread.sleep(1000);
		
		WebElement mon =driver.findElement(By.className("react-datepicker__month-select"));
		new Select(mon).selectByVisibleText(month);
		Thread.sleep(1000);
		WebElement Year =driver.findElement(By.className("react-datepicker__year-select"));
		new Select(Year).selectByVisibleText(year);
		
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector("div.react-datepicker__day.react-datepicker__day--0"+ day)).click();
		Thread.sleep(1000);
		click("Submit_XPATH");			 
	}
	
	public boolean reviewName(String Fname , String Lname)
	{
		String name = Fname + " " + Lname;
		
		return (name.equalsIgnoreCase(gettext("SubmittedName_XPATH")));
	}
	
	public boolean reviewGender(String gender)
	{
		return (gender.equalsIgnoreCase(gettext("SubmittedGender_XPATH")));
	}
	
	public boolean reviewEmail(String Email)
	{
		return (Email.equalsIgnoreCase(gettext("SubmittedEmail_XPATH")));
	}
	
	public boolean reviewMobile(String Mobile)
	{
		return (Mobile.equalsIgnoreCase(gettext("SubmittedMobile_XPATH")));
	}

	public boolean reviewDOB(String Day , String Month , String Year)
	{
		
		String Date = Day + " " + getMonthForInt(Integer.parseInt(Month)) + "," + Year;
		System.out.println(Date);
		System.out.println(gettext("SubmittedDOB_XPATH"));
		return (Date.equalsIgnoreCase(gettext("SubmittedDOB_XPATH")));
	}

	public boolean reviewSubjects(String[] subjects)
	{
		String Subjects = "" ;
		for(int i = 0 ; i <= subjects.length - 2 ; i++)
		{ 
		 Subjects +=  subjects[i] + ", " ;
		}
		Subjects += subjects[subjects.length - 1] ;
		
		return (Subjects.equalsIgnoreCase(gettext("SubmittedSubjects_XPATH")));
	}
	
	public boolean reviewHobbies(String[] hobbies)
	{
		String Subjects = "" ;
		for(int i = 0 ; i <= hobbies.length - 2 ; i++)
		{ 
		 Subjects +=  hobbies[i] + ", " ;
		}
		Subjects += hobbies[hobbies.length - 1] ;
		
		return (Subjects.equalsIgnoreCase(gettext("SubmittedHobbies_XPATH")));
	}
	
	public boolean reviewPicture(String picture)
	{
		String[] pictureFilePath = picture.split("\\\\"); 
		String Picture = pictureFilePath[(pictureFilePath.length)-1];
		
		return (Picture.equalsIgnoreCase(gettext("SubmittedPicture_XPATH")));
	}
	
	public boolean reviewaddress(String address)
	{
		//System.out.println(address);
		//System.out.println(gettext("SubmittedAddress_XPATH"));
		return (address.equalsIgnoreCase(gettext("SubmittedAddress_XPATH")));
	}
	
	public boolean reviewStateCity(String city , String state)
	{
		String State = state + " " + city;
		return (State.equalsIgnoreCase(gettext("SubmittedCityState_XPATH")));
	}
	
}
