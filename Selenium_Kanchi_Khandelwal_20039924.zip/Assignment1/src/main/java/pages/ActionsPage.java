package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ActionsPage extends basePage.Base {

	public void SelectURL(String actions)
	{
		if(actions.equalsIgnoreCase("select"))
			{
			driver.get("http://www.demoqa.com/selectable");
			}
		else if(actions.equalsIgnoreCase("Drop"))
		{
			driver.get("http://www.demoqa.com/droppable");
		}
		else if(actions.equalsIgnoreCase("Date"))
		{
			driver.get("http://www.demoqa.com/date-picker");
		}
		else if(actions.equalsIgnoreCase("DropDown"))
			{
			driver.get("http://www.demoqa.com/select-menu");
			}
	}
	
	public void SelectItems()
	{
		if(visibilityElement("Select_XPATH"))
		{
			click("Select_XPATH");
		}
	}
	
	 public void Draggable()
	 {
		 DragDrop("Drag_XPATH" , "Drop_XPATH");
	 }

	 public void MonthSelection(int month)
	 {
		 click("Date1_ID");
		 SelectDrop("Month_XPATH" , month-1 );
	 }
	 
	 public void YearSelection(int year)
	 {
		 SelectDrop("Year_XPATH" , year );
	 }
	 
	 public void DateSelection(int targetDay)
	 {
		 if (targetDay < 10) {
			 	System.out.println("date");
				DateSelect("Date1_XPATH","Date2_XPATH","Date3_XPATH",targetDay);
			} else {
				System.out.println("date");
				DateSelect("Date1_XPATH","Date4_XPATH","Date3_XPATH",targetDay);
			}
			 
	 }
	 
	 public void MonthTimeSelection(String targetMonth , String currentMonth )
	 {
		 click("Date2_ID");
		 click("Month1_XPATH");
		 WebElement monthname; 
		 if (targetMonth.equalsIgnoreCase(currentMonth)) { 
		monthname = driver.findElement(By.xpath(
		  "//*[@class='react-datepicker__month-option react-datepicker__month-option--selected_month'][text() = '"
		  + targetMonth + "']")); }
		 else {
		monthname = driver.findElement(By.xpath("//*[@class='react-datepicker__month-option'][text() = '" +targetMonth + "']")); 
		}
		  wait.until(ExpectedConditions.elementToBeClickable(monthname));
		  monthname.click(); 
	 }
	 
	 public void YearTimeSelection(int targetYear , int currentYear)
	 {
		 click("Year1_XPATH");
		 int Clicks;
		  if (currentYear > targetYear)
		  { 
			  Clicks = currentYear-5-targetYear; 
			  while(Clicks>0) { 
				  click("Year2_XPATH");
				  Clicks--; 
			  } 
			  driver.findElement(By.xpath("//div[@class='react-datepicker__year-option'][text() = '" + targetYear + "']")).click(); }else

				  
			  {
			Clicks = targetYear - 5 - currentYear;
			while (Clicks > 0) {
					click("Year3_XPATH");
				Clicks--;
			}
			driver.findElement(By.xpath("//div[@class='react-datepicker__year-option'][text() = '" + targetYear + "']"))
					.click();
		}

	 }
	 
	 public void DateTimeSelection(int targetDay , String time)
	 {
		 if (targetDay < 10) {

				DateSelect("Date1_XPATH","Date2_XPATH","Date3_XPATH",targetDay);
			} else {
				System.out.println("date");
				DateSelect("Date1_XPATH","Date4_XPATH","Date3_XPATH",targetDay);
			}		 
		 
		 driver.findElement(By.xpath("//li[@class='react-datepicker__time-list-item '][text() = '"+time+"']")).click();
		 
	 }
	 
	 public boolean SelectMenu(String value)
	 {
		 click("Clickmenu1_XPATH");
		 SelectByMenu("Menu1_XPATH","Menu2_XPATH",value);
		 
		 return (gettext("Assert1_XPATH").equalsIgnoreCase(value));
		 
	 }
	 public boolean SelectMenu1(String value) throws InterruptedException
	 {
		 click("Clickmenu2_ID");
		 Thread.sleep(1000);
		 SelectByMenu("Menu1_XPATH","Menu2_XPATH",value);
		 
		 return (gettext("Assert2_XPATH").equalsIgnoreCase(value));
		 
	 }
	 
	 public void SelectMenu2(int value) throws InterruptedException
	 {
		 
		 SelectDrop("Clickmenu3_XPATH" , value);
		 
	 }
}
