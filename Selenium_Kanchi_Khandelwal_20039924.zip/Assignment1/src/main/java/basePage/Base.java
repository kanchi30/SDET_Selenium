package basePage;


	
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;
import java.util.List;
import java.util.Properties;

	import org.apache.log4j.Logger;
	import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import Listeners.Listeners;

	public class Base {

		public static WebDriver driver;
		public static Properties OR = new Properties();
		public static FileInputStream fis;
		public static Logger log = Logger.getLogger("devpinoyLogger");
		public static WebDriverWait wait;
		
		public Base() {

			try {
				fis = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/Properties/OR.properties");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				OR.load(fis);
				log.debug("OR file loaded !!!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		

		}

		public void selectDriver(WebDriver driver)
		{		
			this.driver = driver;
			log.debug("Browser selected");
		}
		
		public static void click(String locator) {
			
			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).click();
			} else if (locator.endsWith("_XPATH")) {
				System.out.println("in xpath");
				driver.findElement(By.xpath(OR.getProperty(locator))).click();
			} else if (locator.endsWith("_ID")) {
				System.out.println("Id");
				driver.findElement(By.id(OR.getProperty(locator))).click();
			}
			log.debug("Clicking on an Element : " + locator);
			Listeners.testReport.get().log(Status.INFO, "Clicking on : " + locator);
		}

		public static void hold()
		{
			wait = new WebDriverWait(driver,100);
		}
		
		public static String gettext(String locator) {
			String text = null;
			if (locator.endsWith("_CSS")) {
				text = driver.findElement(By.cssSelector(OR.getProperty(locator))).getText();
			} else if (locator.endsWith("_XPATH")) {
				text = driver.findElement(By.xpath(OR.getProperty(locator))).getText();
			} else if (locator.endsWith("_ID")) {
				text = driver.findElement(By.id(OR.getProperty(locator))).getText();
			}
			log.debug("Getting text of an element :" + locator);
			Listeners.testReport.get().log(Status.INFO, "Getting text of : " + locator);
			return text;

		}

		public static void type(String locator, String value) {

			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).sendKeys(value);
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);
			}

			log.debug("Typing in an Element : " + locator + " entered value as : " + value);
			Listeners.testReport.get().log(Status.INFO, "Typing in : " + locator + " entered value as " + value);

		}
		
		public boolean isElementPresent(String locator) {

			try {

				driver.findElement(By.xpath(OR.getProperty(locator)));
				log.debug("Element found : " + locator);
				return true;

			} catch (NoSuchElementException e) {

				return false;

			}
		}

		public boolean visibilityElement(String locator)
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(OR.getProperty(locator)))));
				return true;
			}
			catch(NoSuchElementException e)
			{
				return false;	
			}
			
			
		}
		

		public void DragDrop(String Drag , String Drop)
		{
			WebElement src = driver.findElement(By.xpath(OR.getProperty(Drag)));
			WebElement dest = driver.findElement(By.xpath(OR.getProperty(Drop)));
			
			Actions action = new Actions(driver);
			action.dragAndDrop(src, dest);
		}
		
		public void SelectDrop(String locator , int value)
		{
			Select select = new Select(driver.findElement(By.xpath(OR.getProperty(locator))));
			List<WebElement> option = select.getOptions();
			for (WebElement mon : option) {
				if(mon.getAttribute("value").equalsIgnoreCase("Red"))
				{break; }
				else if (Integer.parseInt(mon.getAttribute("value")) == value) {
					select.selectByValue(Integer.toString(value));
					break;
				}
		
			}

			log.debug("Selecting from an element : "+locator+" value as : "+value);
		//	Test.log(Status.INFO, "Selecting from dropdown : " + locator + " value as " + value);
		}
		
		public void DateSelect(String locator1 , String locator2 ,String locator3, int value) {

			if (locator1.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator1)+value+OR.getProperty(locator2)+value+OR.getProperty(locator3))).click();
			} else if (locator1.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator1)+value+OR.getProperty(locator2)+value+OR.getProperty(locator3))).click();
			} else if (locator1.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator1)+value+OR.getProperty(locator2)+value+OR.getProperty(locator3))).click();
		
		}
	}
		
		public void SelectByMenu(String locator1 ,String locator2,String value )
		{
			Actions action = new Actions(driver);
			action.moveToElement(driver.findElement(By.xpath(OR.getProperty(locator1)+value+OR.getProperty(locator2))));
			action.click().build().perform();
		}
		
		
	}