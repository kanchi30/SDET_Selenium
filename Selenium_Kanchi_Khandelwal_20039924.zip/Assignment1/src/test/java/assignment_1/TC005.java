package assignment_1;

import org.testng.annotations.Test;
import pages.ActionsPage;

public class TC005 extends Initialization {
	
	@Test(testName="option1" , priority=3)
	public static void SelectMenuValue() throws Exception {
		
		ActionsPage action = new ActionsPage();
		
		action.SelectURL("DropDown");

		softassert.assertTrue(action.SelectMenu("Group 1, option 1"));
		softassert.assertTrue(action.SelectMenu("Group 1, option 2"));
		softassert.assertTrue(action.SelectMenu("Group 2, option 1"));
		softassert.assertTrue(action.SelectMenu("Group 2, option 2"));
		softassert.assertTrue(action.SelectMenu("A root option"));
		softassert.assertTrue(action.SelectMenu("Another root option"));
		softassert.assertAll();
		}



@Test(testName="option2" , priority=2)
public static void SelectMenuone() throws Exception {
	
	ActionsPage action = new ActionsPage();
	
	action.SelectURL("DropDown");
	
	softassert.assertTrue(action.SelectMenu1("Other"));
	softassert.assertTrue(action.SelectMenu1("Dr."));
	softassert.assertTrue(action.SelectMenu1("Mr."));
	softassert.assertTrue(action.SelectMenu1("Mrs."));
	softassert.assertTrue(action.SelectMenu1("Ms."));
	softassert.assertTrue(action.SelectMenu1("Prof."));
	softassert.assertTrue(action.SelectMenu1("Ms."));
	
	softassert.assertAll();
}
@Test(testName="option3" , priority=1)
public static void SelectMenuold() throws Exception {
	
	ActionsPage action = new ActionsPage();
	
	action.SelectURL("DropDown");
		
	int i=1;
	for(i = 1 ; i<=10 ;i++)
	{
		action.SelectMenu2(i);
		
	}
	
}
}
