package assignment_1;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import pages.ActionsPage;

public class TC003 extends Initialization{
	
	@Test
	public static void DragDrop() throws Exception {
		
		ActionsPage action = new ActionsPage();
		action.SelectURL("Drop");
		
		action.Draggable();
		
		boolean value = ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class = 'drop-box ui-droppable ui-state-highlight']"))!=null;
		softassert.assertTrue(value, "not dragged");
		softassert.assertAll();
	}
}
