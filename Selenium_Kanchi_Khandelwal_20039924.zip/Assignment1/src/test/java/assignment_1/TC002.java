package assignment_1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DateFormatSymbols;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import basePage.Base;
import pages.FormPage;

public class TC002 extends Initialization {
	
	

	@DataProvider(name = "Form_data")
	private Object[][] formData() throws FileNotFoundException {

		String fileName = "FormData.json";
		String filePath = getClass().getClassLoader().getResource(fileName).getPath();

		JsonElement jsonData = new JsonParser().parse(new FileReader(filePath));
		JsonElement formData = jsonData.getAsJsonObject().get("form");
		List<JSONData> testData = new Gson().fromJson(formData,
				new TypeToken<List<JSONData>>() {
				}.getType());
		Object[][] returnValue = new Object[testData.size()][1];
		int index = 0;
		for (Object[] each : returnValue) {
			each[0] = testData.get(index++);

		}
		return returnValue;
	}
	 public static	String getMonthForInt(int m) {
			m = m- 1 ; 
		    String month = "invalid";
		    DateFormatSymbols dfs = new DateFormatSymbols();
		    String[] months = dfs.getMonths();
		    if (m >= 0 && m <= 11 ) {
		        month = months[m];
		    }
		    return month;
		}
	
	@Test(dataProvider = "Form_data")
	public void AutomationForm(JSONData formData) throws InterruptedException {
		FormPage cursor = new FormPage();
		cursor.SelectURL();
		Base.hold();
		
		cursor.FirstName(formData.getFirstName());
		System.out.println("Fname");
		cursor.LastName(formData.getLastName());
		System.out.println("Fname");
		cursor.Mobile(formData.getMobile());
		System.out.println("Fname");
		cursor.Address(formData.getCurrentAddress());
		System.out.println("Fname");
		cursor.Gender(formData.getGender());
		System.out.println("Fname");
		cursor.Hobbies(formData.getHobbies());
		System.out.println("Fname");
		cursor.Email(formData.getEmail());
		System.out.println("Fname");
		cursor.State(formData.getState());
		System.out.println("Fname");
		cursor.City(formData.getCity());
		System.out.println("Fname");
		cursor.picture(formData.getPicture());
		System.out.println("Fname");
		cursor.Subject(formData.getSubjects());
		cursor.selectBirthdate(formData.getMonth(), formData.getYear() ,formData.getDay());
		Assert.assertTrue(cursor.reviewaddress(formData.getCurrentAddress()));
		Assert.assertTrue(cursor.reviewDOB(formData.getDay(), formData.getMonth(), formData.getYear()));
		Assert.assertTrue(cursor.reviewName(formData.getFirstName(), formData.getLastName()));
		Assert.assertTrue(cursor.reviewEmail(formData.getEmail()));
		Assert.assertTrue(cursor.reviewGender(formData.getGender()));
		Assert.assertTrue(cursor.reviewHobbies(formData.getHobbies()));
		Assert.assertTrue(cursor.reviewMobile(formData.getMobile()));
		Assert.assertTrue(cursor.reviewPicture(formData.getPicture()));
		Assert.assertTrue(cursor.reviewStateCity(formData.getCity(), formData.getState()));  
		Assert.assertTrue(cursor.reviewSubjects(formData.getSubjects()));
		
		 }
	
}