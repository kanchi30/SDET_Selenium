package assignment_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import basePage.Base;
import pages.ActionsPage;

public class TC004 extends Initialization {
	@DataProvider(name = "date")
	public static Object[][] datePick() throws Exception {
		Object[][] obj = ExcelReader.getTableArray(
				"C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment1\\src\\test\\resources\\Assignment_1.xlsx",
				"Date");
		return obj;
	}

	@DataProvider(name = "datetime")
	public static Object[][] datetimePick() throws Exception {
		Object[][] obj = ExcelReader.getTableArray(
				"C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment1\\src\\test\\resources\\Assignment_1.xlsx",
				"DateTime");
		return obj;
	}

	@Test(dataProvider = "date")
	public static void DatePicker(String date) throws Exception {

		ActionsPage action = new ActionsPage();
		action.SelectURL("Date");

		GetTargetDate(date);

		action.MonthSelection(targetMonth);
		action.YearSelection(targetYear);
		action.DateSelection(targetDay);
		// Selection of date
		WebElement SelectedDate = driver.findElement(By.xpath("//*[@id='datePickerMonthYearInput']"));
		// date = Month + "/" + Day + "/" + Year;
		System.out.println(SelectedDate.getAttribute("value"));
		// softassert.assertEquals(SelectedDate.getAttribute("value"), date);
		// softassert.assertAll();
	}

	@Test(testName = "date_time", dataProvider = "datetime") 
	  public static void DateTimePicker(String date,String time) throws Exception
	{
		 ActionsPage action = new ActionsPage();
		 action.SelectURL("Date");
		 Base.hold();
		 
	  GetCurrentDate(); 
	  // selection of month
	  action.MonthTimeSelection(MonthNameSelect.monthNameSelect(targetMonth) , MonthNameSelect.monthNameSelect(currentMonth));
	  
	  // selection of year 
	  action.YearTimeSelection(targetYear, currentYear);

	// System.out.println(targetDay); // Selection of date 
	  

	  action.DateTimeSelection(targetDay , time);
	  System.out.println(driver.findElement(By.id("dateAndTimePickerInput")).getAttribute("value"));
	
}

}
