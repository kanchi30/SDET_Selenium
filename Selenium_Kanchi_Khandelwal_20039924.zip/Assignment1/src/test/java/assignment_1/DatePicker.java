package assignment_1;

	
	import java.util.Calendar;

	public class DatePicker {

		static int targetDay=0,
				targetMonth=0,
				targetYear=0;
		static String Day=null,
				Month=null,
				Year=null;
		
		
		static int currentDay=0,
				currentMonth=0,
				currentYear=0;
		
		static int jumpByMonth=0;
		static boolean increment = true;
		
		public static void GetCurrentDate()
		{
			Calendar cal = Calendar.getInstance();
			currentDay = cal.get(Calendar.DAY_OF_MONTH);
			currentMonth=cal.get(Calendar.MONTH);
			currentYear=cal.get(Calendar.YEAR);	
		}
		
		public static void GetTargetDate(String DateToSet)
		{
			int firstIndex = DateToSet.indexOf('/');
			int	lastIndex = DateToSet.lastIndexOf('/');
			
			Day = DateToSet.substring(0, firstIndex);
			targetDay = Integer.parseInt(Day);
			Month =	DateToSet.substring(firstIndex+1, lastIndex);
			targetMonth = Integer.parseInt(Month);
			Year = DateToSet.substring(lastIndex+1, DateToSet.length());
			targetYear = Integer.parseInt(Year);
			  
		}
		
		public static void HowManyMonthsToJump() {
			if(currentMonth > targetMonth )
			{
				jumpByMonth = (currentMonth-targetMonth);
			}
			else
			{
				jumpByMonth = (targetMonth-currentMonth);
				increment = false;
			}
		}

}
