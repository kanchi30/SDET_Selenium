package assignment_1;

import org.testng.annotations.Test;

import basePage.Base;
import pages.ActionsPage;

public class TC001 extends Initialization{
		@Test
	public static void Selectable() throws Exception {
		
		ActionsPage actions = new ActionsPage();
		actions.SelectURL("select");
		Base.hold();
		for (int i = 1; i < 5; i++) {
			actions.SelectItems();
		}
		
	}

}
