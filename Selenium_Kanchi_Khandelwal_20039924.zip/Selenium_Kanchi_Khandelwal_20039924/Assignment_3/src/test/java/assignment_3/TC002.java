package assignment_3;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;

import assignment_3.Initialization;
@Listeners(ListenerTest.class)
public class TC002 extends Initialization  {

	@DataProvider(name = "Travel_Details")
	public Object[][] DataProvide() throws Exception {
		Object[][] obj = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_3\\src\\test\\resources\\MakeMyTrip.xlsx", "RoundTrip");
		return obj;
	};

	@Test(dataProvider = "Travel_Details" , testName="two Way")
	public void TwoWay(String Src, String Dest, String date,String rtrn) throws InterruptedException, IOException {
	
		// Navigation to makeMyTrip
		
		WebDriverWait wait = new WebDriverWait(driver, 100);
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");
		
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/ul/li[6]")).click();
		
		// two way selection
		WebElement btn = driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/div/div[1]/ul/li[2]"));
		btn.click();
		softassert.assertEquals(btn.getAttribute("class"), "selected", "Two way is not selected");
		
		// Source airport selection
		driver.findElement(By.xpath("//span[contains(text(),'From')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'From']")).sendKeys(Src);
		WebElement src = driver.findElement(By.xpath("//div/p[contains(text(),'" + Src + "')]"));
		Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOf(src));
		src.click();
		boolean value = driver.findElement(By.xpath("//input[@id='fromCity']")).getAttribute("value").contains(Src);
		softassert.assertTrue(value,"Source Not Found");

		// Destination airport selection
		driver.findElement(By.xpath("//span[contains(text(),'To')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'To']")).sendKeys(Dest);
		Thread.sleep(1000);
		WebElement dst = driver.findElement(By.xpath("//div[@class='calc60']/p[contains(text(),'" + Dest + "')][1]"));
		wait.until(ExpectedConditions.visibilityOf(dst));
		dst.click();
		value = driver.findElement(By.xpath("//input[@id='toCity']")).getAttribute("value").contains(Dest);
		softassert.assertTrue(value,"Destination not found");
		Thread.sleep(1000);
		// Selection of travel Date
		driver.findElement(By.xpath("//span[@class = 'lbl_input latoBold appendBottom10']")).click();
		driver.findElement(By.xpath("//div[contains(@aria-label,'"+date+"')]")).click();
		
		//Selection of return Date
		//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[4]")).click();
		WebElement retrn = driver.findElement(By.xpath("//div[contains(@aria-label,'" + rtrn + "')]"));
		new Actions(driver).moveToElement(retrn).click().build().perform();
		// click on search button
		driver.findElement(By.xpath("//a[text() = 'Search']")).click();
		
		softassert.assertEquals(driver.getTitle(), "Makemytrip");

		softassert.assertAll();
		
		WebElement price = driver.findElement(By.cssSelector("p.actual-price"));
		@SuppressWarnings("unused")
		String price1 = price.getText().toString();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[text() = 'Book Now']")).click();  
		driver.findElement(By.xpath("//*[@id='left-side--wrapper']/div/div/div[5]/div[3]/div[2]/button")).click();
		softassert.assertEquals(driver.getTitle(), "Makemytrip");
		Set<String> windID = driver.getWindowHandles();
		Iterator<String> itr = windID.iterator();
		@SuppressWarnings("unused")
		String windID1 = itr.next();
		String windID2 = itr.next();
		driver.switchTo().window(windID2);
		String dept = driver.findElement(By.xpath("//p/span[text() = '"+Src+"']")).getText(); 
		String arr = driver.findElement(By.xpath("//p/span[text() = '"+ Dest+"']")).getText();

		@SuppressWarnings("unused")
		WebElement Price = driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div[2]/div[1]/div[2]/div[1]/div/div[4]/p/span[2]"));
		
		softassert.assertEquals(dept, Src);
		softassert.assertEquals(arr, Dest);
		//softassert.assertEquals(price1, Price);
		softassert.assertAll();
		}

}
