package assignment_3;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class TC001 {

	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		driver.get("https://www.makemytrip.com/");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[1]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'From')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'From']")).sendKeys("Pune");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()='PNQ']/parent::div/parent::li")).click();
		driver.findElement(By.xpath("//span[contains(text(),'To')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'To']")).sendKeys("Bhopal");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text() = 'BHO']/parent::div/parent::li")).click();
		driver.findElement(By.xpath("//span[@class = 'lbl_input latoBold appendBottom10']")).click();
		driver.findElement(By.xpath("//div[@aria-label = 'Sun Jun 14 2020']")).click();
		driver.findElement(By.xpath("//a[text() = 'Search']")).click();
		driver.findElement(By.xpath("//div[@class='pull-left make_relative']")).click();
		Set<String> windID = driver.getWindowHandles();
		Iterator<String> itr = windID.iterator();
		@SuppressWarnings("unused")
		String windID1 = itr.next();
		String windID2 = itr.next();
		driver.switchTo().window(windID2);
		System.out.println(driver.getCurrentUrl());
		Thread.sleep(2000);
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		ImageIO.write(screenshot.getImage(),"jpg",new File("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\SDET\\src\\test\\resources\\oneway.jpg"));
	}

}
