package assignment_3;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(ListenerTest.class)
public class TC001 extends Initialization {
	
	@DataProvider(name="Travel_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_3\\src\\test\\resources\\MakeMyTrip.xlsx" , "OneWay");
		return obj;
	};		
	
	@SuppressWarnings("unused")
	@Test(dataProvider ="Travel_Details", testName="one-Way")
	public void OneWay(String Src , String Dest , String date) throws InterruptedException, IOException {
		System.out.println("In test");
		WebDriverWait wait = new WebDriverWait(driver,100);
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/ul/li[6]")).click();
		//One way selection
		WebElement btn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[1]"));
		btn.click();
		softassert.assertEquals(btn.getAttribute("class"), "selected", "One way is not selected");
		
		//Source airport selection
		driver.findElement(By.xpath("//span[contains(text(),'From')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'From']")).sendKeys(Src);
		Thread.sleep(2000);
		WebElement src = driver.findElement(By.xpath("//div/p[contains(text(),'"+ Src + "')]"));
		wait.until(ExpectedConditions.visibilityOf(src));
		src.click();
		boolean value = driver.findElement(By.xpath("//input[@id='fromCity']")).getAttribute("value").contains(Src);
		softassert.assertTrue(value,"Source Not Found");
		
		//Destination airport selection
		driver.findElement(By.xpath("//span[contains(text(),'To')]")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'To']")).sendKeys(Dest);
		Thread.sleep(2000);
		WebElement dst = driver.findElement(By.xpath("//div[@class='calc60']/p[contains(text(),'"+ Dest + "')]"));
		wait.until(ExpectedConditions.visibilityOf(dst));	
		driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-0\"]")).click();
		value = driver.findElement(By.xpath("//input[@id='toCity']")).getAttribute("value").contains(Dest);
		softassert.assertTrue(value,"Destination not found");
	
		//Selection of travel Date
		System.out.println("2");
		driver.findElement(By.xpath("//span[@class = 'lbl_input latoBold appendBottom10']")).click();
		driver.findElement(By.xpath("//div[contains(@aria-label,'"+date+"')]")).click();
		//click on search button
		Thread.sleep(2000);
		WebElement search = driver.findElement(By.xpath("//a[text() = 'Search']"));
		wait.until(ExpectedConditions.visibilityOf(search));
		search.click();
		softassert.assertEquals(driver.getTitle(), "Makemytrip" );
		softassert.assertAll();
		
		driver.findElement(By.xpath("//div[@class='pull-left make_relative']")).click();
		
		if(driver.findElements(By.xpath("//*[@class='fli-list one-way']/div[3]/div[1]/div[2]/div[2]/div[2]")).size() > 0 )
		{		
			driver.findElement(By.xpath("//*[@class='fli-list one-way']/div[3]/div[1]/div[2]/div[2]/div[2]")).click();
		}

		WebElement price = driver.findElement(By.xpath("//*[@class='fli-list one-way']/div[1]/div[1]/div/div/div/div[3]/p/span[@class='actual-price']"));
		
		Set<String> windID = driver.getWindowHandles();
		Iterator<String> itr = windID.iterator();
		@SuppressWarnings("unused")
		String windID1 = itr.next();
		String windID2 = itr.next();
		driver.switchTo().window(windID2);
	
		softassert.assertEquals(driver.getTitle(), "Makemytrip" );
		String dept = driver.findElement(By.xpath("//p/span[contains(text() ,'"+Src+"')]")).getText(); 
		String arr = driver.findElement(By.xpath("//p/span[contains(text() ,'"+ Dest+"')]")).getText().toString();
		System.out.println(dept);
		System.out.println(arr);
		WebElement Price = driver.findElement(By.xpath("//*[@id='root']/div/div[2]/div[2]/div[1]/div[2]/div[1]/div/div[4]/p/span[2]"));
		System.out.println("1");
		softassert.assertEquals(dept, Src);
		softassert.assertEquals(arr, Dest);
		//softassert.assertEquals(price1, Price.getText());
		System.out.println("2");
		softassert.assertAll();
	}
	
}


