package assignment_3;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
@Listeners(ListenerTest.class)
public class TC003 extends Initialization {

	@DataProvider(name = "Travel_Details")
	public Object[][] DataProvide() throws Exception {
		Object[][] obj = ExcelReader.getTableArray("C://Users//khand//Desktop//MakeMyTrip.xlsx", "MultiCity");
		return obj;
	}

	@Test(dataProvider = "Travel_Details" , testName="Multi_Way")
	public void MultiCity(String Src,String Mid, String Dest, String date,String rtrn) throws InterruptedException, IOException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		// Navigation to makeMyTrip
		WebDriverWait wait = new WebDriverWait(driver, 100);
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/ul/li[6]")).click();
		
		//MultiCity Selection
		WebElement btn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[3]"));
		btn.click();
		softassert.assertEquals(btn.getAttribute("class"), "selected", "Multicity is not selected");
		
		//source selection
		driver.findElement(By.xpath("//label[@for='fromAnotherCity0']")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'From']")).sendKeys(Src);
		Thread.sleep(1000);
		WebElement src = driver.findElement(By.xpath("//div/p[contains(text(),'"+Src+"')][1]"));
		wait.until(ExpectedConditions.visibilityOf(src));
		src.click();
		boolean value = driver.findElement(By.xpath("//input[@id='fromAnotherCity0']")).getAttribute("value").contains(Src);
		softassert.assertTrue(value,"Source Not Found");

		//Mid Selection
		//driver.findElement(By.xpath("//label[@for='toAnotherCity0']")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'To']")).sendKeys(Mid);
		Thread.sleep(1000);
		WebElement mid = driver.findElement(By.xpath("//div/p[contains(text(),'"+ Mid +"')][1]"));
		wait.until(ExpectedConditions.visibilityOf(mid));
		mid.click();
		value = driver.findElement(By.xpath("//input[@id='toAnotherCity0']")).getAttribute("value").contains(Mid);
		softassert.assertTrue(value,"Mid Destination Not Found");
		
		//Selection of first departure date
		//driver.findElement(By.xpath("//label[@for='anotherDeparture 0']")).click();
		driver.findElement(By.xpath("//div[contains(@aria-label ,'"+ date +"']")).click();
		
		//Selection of destination
		driver.findElement(By.xpath("//label[@for='toAnotherCity1']")).click();
		driver.findElement(By.xpath("//input[@placeholder = 'To']")).sendKeys(Dest);
		Thread.sleep(1000);
		WebElement dst = driver.findElement(By.xpath("//div/p[contains(text(),'"+Dest+"')]"));
		wait.until(ExpectedConditions.visibilityOf(dst));
		driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-0\"]")).click();
		value = driver.findElement(By.xpath("//input[@id='toAnotherCity1']")).getAttribute("value").contains(Dest);
		softassert.assertTrue(value,"Destination Not Found");
		
		//return date
		WebElement Rtrn = driver.findElement(By.xpath("//div[contains(@aria-label,'"+ rtrn +"']"));
		js.executeScript("arguments[0].scrollIntoView(true);", Rtrn );
		Rtrn.click();
		
		//search button
		driver.findElement(By.xpath("//a[@class='primaryBtn font24 latoBold widgetSearchBtn  widgetSearchBtnMultiCity']")).click();
		softassert.assertEquals(driver.getTitle(), "Makemytrip");
		
		//BookNow button		
		driver.findElement(By.xpath("//button[text() = 'Book Now']")).click();
		Set<String> windID = driver.getWindowHandles();
		Iterator<String> itr = windID.iterator();
		@SuppressWarnings("unused")
		String windID1 = itr.next();
		String windID2 = itr.next();
		driver.switchTo().window(windID2);
		softassert.assertEquals(driver.getTitle(), "Makemytrip");
		src = driver.findElement(By.xpath("//span[text()='"+Src+"']"));
		mid = driver.findElement(By.xpath("//p[@class='arrival-city']/span[text()='"+Mid+"']"));
		dst = driver.findElement(By.xpath("//span[text()='"+Dest+"']"));
		softassert.assertEquals(src.getText(), Src);
		softassert.assertEquals(mid.getText(), Mid);
		softassert.assertEquals(dst.getText(), Dest);
		softassert.assertAll();
		
	}

}
