package assignment_1;

public class JSONData {
	private String FirstName;
	private String LastName;
	private String Email;
	private String Gender;
	private String Mobile;
	private String Day;
	private String Month;
	private String Year;
	private String Picture;
	private String[] Subjects;
	private String[] Hobbies;
	private String CurrentAddress;
	private String State;
	private String City;
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return FirstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return LastName;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return Gender;
	}
	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return Mobile;
	}
	/**
	 * @return the day
	 */
	public String getDay() {
		return Day;
	}
	/**
	 * @return the month
	 */
	public String getMonth() {
		return Month;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return Year;
	}
	/**
	 * @return the picture
	 */
	public String getPicture() {
		return Picture;
	}
	/**
	 * @return the subjects
	 */
	public String[] getSubjects() {
		return Subjects;
	}
	/**
	 * @return the hobbies
	 */
	public String[] getHobbies() {
		return Hobbies;
	}
	/**
	 * @return the currentAddress
	 */
	public String getCurrentAddress() {
		return CurrentAddress;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return State;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return City;
	}
	

}
