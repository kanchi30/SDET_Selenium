package assignment_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TC001 extends Initialization{
		@Test
	public static void Selectable() throws Exception {
		driver.get("http://www.demoqa.com/selectable");
		SoftAssert softassert = new SoftAssert();
		WebDriverWait wait = new WebDriverWait(driver, 2000);
		Assert.assertEquals("http://www.demoqa.com/selectable", driver.getCurrentUrl());
		WebElement select ;
		WebElement isSelected;
		boolean value = true;
		for (int i = 1; i < 5; i++) {
			
			select = driver.findElement(By.xpath("//div[@class='row']/div[@class='col-12 mt-4 col-md-6']/div[@class='list-container']/div[@class='tab-content']/div/ul/li[@class='mt-2 list-group-item list-group-item-action'][1]"));
			System.out.println(select);
			wait.until(ExpectedConditions.visibilityOf(select));
			select.click();
			isSelected = driver.findElement(By.xpath("//div[@class='row']/div[@class='col-12 mt-4 col-md-6']/div[@class='list-container']/div[@class='tab-content']/div/ul/li[@class='mt-2 list-group-item active list-group-item-action']["+ i +"]"));
			value = ExpectedConditions.visibilityOf(isSelected) != null;
 			softassert.assertTrue(value, "Element not selected");
		}
		System.out.println("All are selected");
		softassert.assertAll();
	}

}
