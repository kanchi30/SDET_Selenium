package assignment_1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.text.DateFormatSymbols;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import assignment_1.JSONData;

public class TC002 extends Initialization {
	
	

	@DataProvider(name = "Form_data")
	private Object[][] formData() throws FileNotFoundException {

		String fileName = "FormData.json";
		String filePath = getClass().getClassLoader().getResource(fileName).getPath();

		JsonElement jsonData = new JsonParser().parse(new FileReader(filePath));
		JsonElement formData = jsonData.getAsJsonObject().get("form");
		List<JSONData> testData = new Gson().fromJson(formData,
				new TypeToken<List<JSONData>>() {
				}.getType());
		Object[][] returnValue = new Object[testData.size()][1];
		int index = 0;
		for (Object[] each : returnValue) {
			each[0] = testData.get(index++);

		}
		return returnValue;
	}
	 public static	String getMonthForInt(int m) {
			m = m- 1 ; 
		    String month = "invalid";
		    DateFormatSymbols dfs = new DateFormatSymbols();
		    String[] months = dfs.getMonths();
		    if (m >= 0 && m <= 11 ) {
		        month = months[m];
		    }
		    return month;
		}
	
	@Test(dataProvider = "Form_data")
	public void Form(JSONData formData) throws InterruptedException {
		driver.get("http://demoqa.com/automation-practice-form");
		System.out.println(formData.getFirstName());
		System.out.println(formData.getLastName());
		System.out.println(formData.getDay());
		System.out.println(formData.getCity());
		System.out.println(formData.getCurrentAddress());
		System.out.println(formData.getMobile());
		System.out.println(formData.getPicture());
		System.out.println(formData.getState());
		System.out.println(formData.getYear());
		System.out.println(formData.getGender());
		System.out.println(formData.getMonth());
		for(int i = 0 ; i < formData.getHobbies().length ; i++)
		{System.out.println(formData.getHobbies()[i]);
		}
		for(int i = 0 ; i < formData.getSubjects().length ; i++)
		{System.out.println(formData.getSubjects()[i]);
		}
		WebDriverWait wait=new WebDriverWait(driver, 10);
		
	driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys(formData.getFirstName());
	driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys(formData.getLastName());
	driver.findElement(By.xpath("//*[@id=\"userNumber\"]")).sendKeys(formData.getMobile());
	driver.findElement(By.xpath("//*[@id=\"currentAddress\"]")).sendKeys(formData.getCurrentAddress());
	
	driver.findElement(By.xpath("//*[@id=\"subjectsContainer\"]")).click();
	
	for(int i = 0 ; i < formData.getSubjects().length ; i++)
	{
	
	driver.findElement(By.xpath("//*[@id=\"subjectsInput\"]")).sendKeys(formData.getSubjects()[i]);
	
	
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class=\"subjects-auto-complete__menu-list subjects-auto-complete__menu-list--is-multi css-11unzgr\"]")));
	driver.findElement(By.xpath("//*[@id=\"subjectsInput\"]")).sendKeys(Keys.ENTER);
	//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class=\"subjects-auto-complete__menu-list subjects-auto-complete__menu-list--is-multi css-11unzgr\"]")));
	}
	//driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]")).click();
		String Radio = formData.getGender() ;
		
	if(Radio.equals("Male")) {
	// "//*[@id=\"genterWrapper\"]/div[2]/div[1]" ;
	 driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]")).click();
			}
	else if(Radio.equals("Female")) { 
		 driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[2]")).click();

}
	else if(Radio.equals("Other"))
	{
		 driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[3]")).click();

		}
	
	for(int i = 0 ; i < formData.getHobbies().length ; i++) {
	if(formData.getHobbies()[i].equals("Sports"))
	driver.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[1]")).click();
	else if(formData.getHobbies()[i].equals("Reading"))
	driver.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[2]")).click();
	else if(formData.getHobbies()[i].equals("Music"))
	driver.findElement(By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[3]")).click();
	
	}	
	
	//System.out.println(Radio);
	//

	driver.findElement(By.xpath("//*[@id=\"userEmail\"]")).sendKeys(formData.getEmail());
	
	
	/* 
	 * Dropdown code below 
	 * Note: only after entering the state value the city dropdown will be active don't change the order.
	 * change the Json data according to the following values 
	 * specific values - 
	 * State   	 		Cities
	 * NCR      		Delhi , Gurgaon ,  Noida
	 * Uttar Pradesh	Agra , Lucknow , Merrut
	 * Haryana			Karnal , Panipat
	 * Rajasthan		Jaipur , Jaiselmer
	 * 
	 * 
	 * */
//	driver.findElement(By.xpath("//*[@id=\"state\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"react-select-3-input\"]")).sendKeys(formData.getState());
	driver.findElement(By.xpath("//*[@id=\"react-select-3-input\"]")).sendKeys(Keys.ENTER);
	
	driver.findElement(By.xpath("//*[@id=\"city\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"react-select-4-input\"]")).sendKeys(formData.getCity());
	driver.findElement(By.xpath("//*[@id=\"react-select-4-input\"]")).sendKeys(Keys.ENTER);
	driver.findElement(By.xpath("//*[@id=\"uploadPicture\"]")).sendKeys(formData.getPicture());
	
	String month =  getMonthForInt(Integer.parseInt(formData.getMonth())) ;
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"dateOfBirthInput\"]")).click();
		
		WebElement mon =driver.findElement(By.className("react-datepicker__month-select"));
		new Select(mon).selectByVisibleText(month);
		//driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select")).sendKeys(month);
		//driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select")).sendKeys(Keys.ENTER);
		WebElement year =driver.findElement(By.className("react-datepicker__year-select"));
		new Select(year).selectByVisibleText(formData.getYear());
		
		//driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select")).sendKeys(formData.getYear());
		//driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select")).sendKeys(Keys.ENTER);
		
		Thread.sleep(2000);
		
		
		  driver.findElement(By.cssSelector(
		  "div.react-datepicker__day.react-datepicker__day--0"+formData.getDay())).
		  click();
		 // driver.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div[4]")).click(); 
		  driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		  
		  String[] pictureFilePath = formData.getPicture().split("\\\\"); String
		  picture = pictureFilePath[(pictureFilePath.length)-1];
		  System.out.println(picture);
		  
		  String StudentName = formData.getFirstName() + " " + formData.getLastName() ;
		  
		  String FormStudentName = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[1]/td[2]")).getText() ;
		  System.out.println("Form s name " + FormStudentName);
		  
		  String Email = formData.getEmail();
		  
		  String FormEmail = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[2]/td[2]")).getText();
		  System.out.println("Form email " +FormEmail);
		  
		  String Gender = formData.getGender() ; System.out.println("Gender " +
		  Gender); String FormGender = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[3]/td[2]")).getText();
		  System.out.println("Form gender " + FormGender);
		  
		  String Mobile = formData.getMobile(); String FormMobile =
		  driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[4]/td[2]")).getText();
		  System.out.println("Form mobile "+ FormMobile);
		 
		  String DOB = formData.getDay() + " " + month + "," + formData.getYear() ;
		  System.out.println("DOB " + DOB);
		 
		  String FormDOB = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[5]/td[2]")).getText();
		  System.out.println("Form DOB  " + FormDOB);
		   
		  String Subjects = "";
		  
		  for(int i = 0 ; i <= formData.getSubjects().length - 2 ; i++) { Subjects +=
		  formData.getSubjects()[i] + ", " ;
		  
		  }
		  
		  Subjects += formData.getSubjects()[formData.getSubjects().length - 1] ;
		  
		  System.out.println("Subject : " + Subjects);
		  
		  String FormSubjects = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[6]/td[2]")).getText();
		  
		  System.out.println("Form Subjects" +FormSubjects);
		  
		  String Hobbies = "";
		  
		  for(int i = 0 ; i <= formData.getHobbies().length - 2 ; i++) { Hobbies +=
		  formData.getHobbies()[i] + ", " ;
		  
		  }
		    
		  
		  Hobbies += formData.getHobbies()[formData.getHobbies().length - 1] ;
		  System.out.println("Hobbies : " + Hobbies);
		  
		  String FormHobbies = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[7]/td[2]")).getText();
		  System.out.println("Form Hobbies " + FormHobbies);
		  System.out.println("Picture "+ picture); String FormPicture =
		  driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[8]/td[2]")).getText();
		  System.out.println("Form Picture " + FormPicture ); String Address =
		  formData.getCurrentAddress() ; System.out.println("Address " + Address);
		  String FormAddress = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[9]/td[2]")).getText();
		  System.out.println("Form Address"+ FormAddress); String StateAndCity =
		  formData.getState() + " " + formData.getCity();
		  System.out.println("State and City " + StateAndCity ); String
		  FormStateAndCity = driver.findElement(By.xpath(
		  "/html/body/div[3]/div/div/div[2]/div/table/tbody/tr[10]/td[2]")).getText();
		  System.out.println("Form State and city" + FormStateAndCity);
		  
		  Assert.assertEquals(FormAddress, Address);
		  System.out.println();
		  Assert.assertEquals(FormDOB, DOB); Assert.assertEquals(FormStudentName,
		  StudentName); 
		  Assert.assertEquals(FormEmail, Email);
		  Assert.assertEquals(FormGender, Gender); Assert.assertEquals(FormHobbies,
		  Hobbies); Assert.assertEquals(FormMobile, Mobile);
		  Assert.assertEquals(FormPicture, picture);
		  Assert.assertEquals(FormStateAndCity, StateAndCity);
		  Assert.assertEquals(FormSubjects, Subjects);
		 }
	
}