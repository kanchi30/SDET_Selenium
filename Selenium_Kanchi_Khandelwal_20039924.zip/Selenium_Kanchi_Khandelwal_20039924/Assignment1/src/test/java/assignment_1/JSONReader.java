package assignment_1;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;



public class JSONReader {

	public static void ReadJSON(String FileName) throws IOException, Exception
	{
		List<String> list = new ArrayList<String>();
		JSONParser jsonparser = new JSONParser();
		FileReader reader = new FileReader(FileName);
		Object userid = jsonparser.parse(reader);
		JSONArray userlist = (JSONArray) userid;
		int i =0;
		JSONObject user;
		System.out.println(userlist.size());
		for(i=0;i<userlist.size();i++)
		{
			user = (JSONObject) userlist.get(i);
			System.out.println(user);			
		}
	}
	
	public static void main(String[] args) throws IOException, Exception
	{
		ReadJSON("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_2\\src\\test\\resources\\Test.JSON");
	}
}
