package assignment_1;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TC005 extends Initialization {
	
	@Test(testName="option1" , priority=1)
	public static void SelectMenuValue() throws Exception {
		driver.get("http://www.demoqa.com/select-menu");
		SoftAssert softassert = new SoftAssert();
		Assert.assertEquals("http://www.demoqa.com/select-menu", driver.getCurrentUrl());
		WebElement list1 = driver.findElement(By.xpath("//div[@id='withOptGroup']/div[@class=' css-yk16xz-control']"));
		list1.click();
		
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Group 1, option 1']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Group 1, option 1");
		softassert.assertAll();
		
		list1.click();
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Group 1, option 2']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Group 1, option 2");
		softassert.assertAll();
		
		list1.click();
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Group 2, option 1']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Group 2, option 1");
		softassert.assertAll();
		
		list1.click();
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Group 2, option 2']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Group 2, option 2");
		softassert.assertAll();
	
		list1.click();
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'A root option']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "A root option");
		softassert.assertAll();
	
		list1.click();
		action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Another root option']")));
		action.click().build().perform();
		softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Another root option");
		softassert.assertAll();}



@Test(testName="option2" , priority=2)
public static void SelectMenuone() throws Exception {
	driver.get("http://www.demoqa.com/select-menu");
	SoftAssert softassert = new SoftAssert();
	Assert.assertEquals("http://www.demoqa.com/select-menu", driver.getCurrentUrl());
	WebElement list1 = driver.findElement(By.xpath("//div[@id='selectOne']/div[@class=' css-yk16xz-control']"));
	list1.click();
	
	Actions action = new Actions(driver);
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Other']")));
	action.click().build().perform();
	
	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Dr.']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@id='selectOne']/div/div/div[@class=' css-1uccc91-singleValue']")).getText(), "Dr.");

	
	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Mr.']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@id='selectOne']/div/div/div[@class=' css-1uccc91-singleValue']")).getText(), "Mr.");
	
	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Mrs.']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@id='selectOne']/div/div/div[@class=' css-1uccc91-singleValue']")).getText(), "Mrs.");
	//softassert.assertAll();
	
	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Ms.']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Ms.");

	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Prof.']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Prof.");

	list1.click();
	action.moveToElement(driver.findElement(By.xpath("//*[text() = 'Other']")));
	action.click().build().perform();
	softassert.assertEquals(driver.findElement(By.xpath("//div[@class=' css-1uccc91-singleValue']")).getText(), "Other");
	softassert.assertAll();}

@Test(testName="option3" , priority=3)
public static void SelectMenuold() throws Exception {
	driver.get("http://www.demoqa.com/select-menu");
	Assert.assertEquals("http://www.demoqa.com/select-menu", driver.getCurrentUrl());
	Select menu = new Select(driver.findElement(By.id("oldSelectMenu")));
	List<WebElement> option = menu.getOptions();
	int i=1;
	for(i = 1 ; i<option.size();i++)
	{
		menu.selectByIndex(i);
		System.out.println(menu.getFirstSelectedOption().getText());
	}
	
}
}
