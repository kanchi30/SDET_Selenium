package assignment_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Initialization extends DatePicker {
	public static WebDriver driver;
	public static SoftAssert softassert = new SoftAssert();
	
	
	public static void SelectBrowser(String browser)
	{
		
		if(browser.equalsIgnoreCase("Chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("FireFox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver= new FirefoxDriver();
		}
	}
	@BeforeClass
	@Parameters({"browser"})
	
	public static void a(String browser)
	{
	//	String name = "Chrome";
		System.out.println("BrowserName: "+ browser);
		SelectBrowser(browser.toString());
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
	}
	
	@AfterClass
	public static void v()
	{
	//	System.out.println("after test");

	driver.quit();
	}
}

