package assignment_1;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TC004 extends Initialization {
		@DataProvider(name = "date")
	public static Object[][] datePick() throws Exception {
		Object[][] obj = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment1\\src\\test\\resources\\Assignment_1.xlsx", "Date");
		return obj;
	}
	
	@DataProvider(name = "datetime")
	public static Object[][] datetimePick() throws Exception {
		Object[][] obj = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment1\\src\\test\\resources\\Assignment_1.xlsx", "DateTime");
		return obj;
	}

	@Test(dataProvider = "date")
	public static void DatePicker(String date) throws Exception {
		driver.get("http://www.demoqa.com/date-picker");
		SoftAssert softassert = new SoftAssert();
		
		Assert.assertEquals("http://www.demoqa.com/date-picker", driver.getCurrentUrl());
		System.out.println(date);
		GetTargetDate(date);
		System.out.println(targetDay);
		System.out.println(targetMonth);
		System.out.println(targetYear);
		driver.findElement(By.id("datePickerMonthYearInput")).click();

		WebElement month = driver.findElement(By.className("react-datepicker__month-select"));
		Select months = new Select(month);
		// System.out.println(months.getOptions().size());
		List<WebElement> option = months.getOptions();
		for (WebElement mon : option) {
			// System.out.println(mon.getAttribute("value"));
			// Selection of month
			if (Integer.parseInt(mon.getAttribute("value")) == targetMonth) {
				System.out.println("selected month");
				months.selectByValue(Integer.toString(targetMonth - 1));
				Thread.sleep(2000);
				break;
			}
		}

		WebElement year = driver.findElement(By.className("react-datepicker__year-select"));
		Select years = new Select(year);
		// System.out.println("Size: "+ years.getOptions().size());
		List<WebElement> optionyear = years.getOptions();
		for (WebElement yea : optionyear) {
			// System.out.println("Year" + yea.getAttribute("value"));
			// Selection of year
			if (Integer.parseInt(yea.getAttribute("value")) == targetYear) {
				System.out.println("selected year");
				System.out.println(Integer.toString(targetYear));
				years.selectByValue(Integer.toString(targetYear));
				break;
			}
		}
		// Selection of date
		if (targetDay < 10) {
			driver.findElement(By.xpath("//div[text() = '" + targetDay
					+ "'][@class='react-datepicker__day react-datepicker__day--00" + targetDay + "']")).click();
			System.out.println("Selected Date" + targetDay);
		} else {
			driver.findElement(By.xpath("//div[text() = '" + targetDay
					+ "'][@class='react-datepicker__day react-datepicker__day--0" + targetDay + "']")).click();
			System.out.println("Selected Date" + targetDay);
		}
		WebElement SelectedDate = driver.findElement(By.xpath("//*[@id='datePickerMonthYearInput']"));
		date = Month + "/" + Day + "/" + Year;
		softassert.assertEquals(SelectedDate.getAttribute("value"), date);
		softassert.assertAll();
	}

	@Test(testName = "date_time", dataProvider = "datetime")
	public static void DateTimePicker(String date,String time) throws Exception {
		driver.get("http://www.demoqa.com/date-picker");
		SoftAssert softassert = new SoftAssert();
		WebDriverWait wait = new WebDriverWait(driver, 2000);
		Assert.assertEquals("http://www.demoqa.com/date-picker", driver.getCurrentUrl());
		//System.out.println(date);
		GetTargetDate(date);
		//System.out.println(targetDay);
		//System.out.println(targetMonth);
		//System.out.println(targetYear);
		driver.findElement(By.id("dateAndTimePickerInput")).click();

		// selection of month
		driver.findElement(By.className("react-datepicker__month-read-view")).click();
		String MonthName = MonthNameSelect.monthNameSelect(targetMonth);
		//System.out.println("month:" + MonthName);
		WebElement monthname;
		if (targetMonth == 6) {
			monthname = driver.findElement(By.xpath(
					"//*[@class='react-datepicker__month-option react-datepicker__month-option--selected_month'][text() = '"
							+ MonthName + "']"));
		} else {
			monthname = driver.findElement(
					By.xpath("//*[@class='react-datepicker__month-option'][text() = '" + MonthName + "']"));
		}
		wait.until(ExpectedConditions.elementToBeClickable(monthname));
		monthname.click();
		//System.out.println("month");
		
		
		// selection of year
		WebElement year = driver.findElement(By.className("react-datepicker__year-read-view"));
		year.click();
		GetCurrentDate();
		int Clicks;
		//System.out.println(currentYear);
		if (currentYear > targetYear) {
				Clicks = currentYear-5-targetYear;
				while(Clicks>0)
				{	
					driver.findElement(By.xpath("//a[@class='react-datepicker__navigation react-datepicker__navigation--years react-datepicker__navigation--years-previous']")).click();
					Clicks--;
				}
				driver.findElement(By.xpath("//div[@class='react-datepicker__year-option'][text() = '" + targetYear + "']")).click();
			}
		 else 
		{
			
				Clicks = targetYear-5-currentYear;
				while(Clicks>0)
				{
					driver.findElement(By.xpath("//a[@class='react-datepicker__navigation react-datepicker__navigation--years react-datepicker__navigation--years-upcoming']")).click();
					Clicks--;
				}
				driver.findElement(
						By.xpath("//div[@class='react-datepicker__year-option'][text() = '" + targetYear + "']")).click();
			}
		

		//System.out.println(targetDay);
		// Selection of date
	if (targetDay < 10) {
		System.out.println("In date");
			driver.findElement(By.xpath("//div[text() = '" + targetDay + "'][@class='react-datepicker__day react-datepicker__day--00" + targetDay + "']")).click();
		//	System.out.println("Selected Date" + targetDay);
		} else {
			driver.findElement(By.xpath("//div[text() = '" + targetDay+ "'][@class='react-datepicker__day react-datepicker__day--0" + targetDay + "']")).click();
			//System.out.println("Selected Date" + targetDay);0
		}

		driver.findElement(By.xpath("//li[@class='react-datepicker__time-list-item '][text() = '"+ time +"']")).click();
		
		
		WebElement SelectedDate = driver.findElement(By.xpath("//*[@id='dateAndTimePickerInput']"));
		
		date = MonthName + " " + targetDay +"," + " " + targetYear + " " + MonthNameSelect.timeSelect(time);
		softassert.assertEquals(SelectedDate.getAttribute("value"), date);
		softassert.assertAll();
	}

	}
