package assignment_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TC003 extends Initialization{
	
	@Test
	public static void Selectable() throws Exception {
		driver.get("http://www.demoqa.com/droppable");
		SoftAssert softassert = new SoftAssert();
		Assert.assertEquals("http://www.demoqa.com/droppable", driver.getCurrentUrl());
		WebElement src = driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/div[1]/div/div[1]"));
		WebElement dest = driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/div[1]/div/div[2]"));
		Actions action = new Actions(driver);
		action.dragAndDrop(src, dest);
		boolean value = ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class = 'drop-box ui-droppable ui-state-highlight']"))!=null;
		softassert.assertTrue(value, "not dragged");
	}
}
