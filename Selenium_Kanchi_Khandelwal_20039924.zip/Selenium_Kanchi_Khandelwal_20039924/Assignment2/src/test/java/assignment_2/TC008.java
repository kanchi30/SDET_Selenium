package assignment_2;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class TC008 extends Initialization {
	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "IncorrectPassword");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Registration(String URL,String Email,String password) {
	
		driver.get(URL);
		Assert.assertEquals(driver.getCurrentUrl(), URL);
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
		
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Assert.assertEquals(driver.getTitle(), "Inicia sesi�n en tu cuenta");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{
			
			Assert.assertEquals(driver.getTitle(), "Anmelden");
		}
			
		else
			{
			Assert.assertEquals(driver.getTitle(), "Login");
		
		}
		//Email 
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_username']")).sendKeys(Email);
		//Password
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_password\"]")).sendKeys(password);
		//Sign In click
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		WebElement error = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_Message']"));
		boolean value;
		
	/***********************/
				//Register click
		if(URL.equals("https://www.olay.es/es-es"))
		{
			value = error.getText().contains("La combinaci�n de correo electr�nico y la contrase�a que has introducido es incorrecta.");
			Assert.assertTrue(value, "Incorrect password");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{	
			value = error.getText().contains("Die eingegebene Kombination aus Passwort und E-Mail-Adresse ist ung�ltig.");
			Assert.assertTrue(value, "Incorrect password");
		}	
		else
		{
			value = error.getText().contains("The email and password combination you entered is incorrect.");
			Assert.assertTrue(value, "Incorrect password");
		}
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_forgotpassword\"]")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		if(URL.equals("https://www.olay.es/es-es"))
		{
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys(Email);
			WebElement ele = driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div/div[3]/div[2]/div/div[2]/div[1]/div/div[1]/input"));
			js.executeScript("arguments[0].scrollIntoView();", ele);	
			ele.sendKeys(Email);
			WebElement cli = driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div/div[3]/div[2]/div/div[2]/div[1]/div/div[2]/font/font/input"));
			js.executeScript("arguments[0].scrollIntoView();", cli);
			cli.click();
		}
		
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_username\"]")).sendKeys(Email);
		driver.findElement(By.xpath("//*[@type='submit']")).click();
		
		
		error = driver.findElement(By.id("phdesktopbody_0_afterSubmit"));
		if(URL.equals("https://www.olay.es/es-es"))
		{
			value = error.getText().contains("Recibir� un correo electr�nico muy pronto con un");
			Assert.assertTrue(value, "Incorrect password");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{	
			value = error.getText().contains("Sie erhalten in K�rze eine E-Mail mit einem Link zum Zur�cksetzen Ihres Passworts.");
			Assert.assertTrue(value, "Reset password");
		}	
		else
		{
			value = error.getText().contains("We have sent an email to your email address");
			Assert.assertTrue(value, "Reset password");
		}
	}
	
}
