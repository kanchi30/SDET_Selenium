//Login Functionality
package assignment_2;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(Listener.class)

public class TC003 extends Initialization {
	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "Login");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Registration(String URL,String Email,String password) throws InterruptedException {
	
		driver.get(URL);
		Assert.assertEquals(driver.getCurrentUrl(), URL);
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
		
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Assert.assertEquals(driver.getTitle(), "Inicia sesi�n en tu cuenta");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{
			
			Assert.assertEquals(driver.getTitle(), "Anmelden");
		}
			
		else
			{
			Assert.assertEquals(driver.getTitle(), "Login");
		
		}
		//Email 
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_username']")).sendKeys(Email);
		//Password
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_password\"]")).sendKeys(password);
		//Sign In click
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
	
	/***********************/
				//Register click
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Thread.sleep(1000);
			Assert.assertEquals(driver.getTitle(), "Ver Perfil");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{	
			Thread.sleep(1000);
			Assert.assertEquals(driver.getTitle(), "ViewProfilePage");
			
		}	
		else
		{
			Thread.sleep(1000);
			Assert.assertEquals(driver.getTitle(), "View Profile");
			
		}
		System.out.println("Sign in success");
	}
	
}
