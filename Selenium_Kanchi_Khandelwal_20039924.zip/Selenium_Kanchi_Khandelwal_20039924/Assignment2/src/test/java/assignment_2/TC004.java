//Password expectation
package assignment_2;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class TC004 extends Initialization {

	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "Password");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Registration(String URL,String Email,String password,String ConPassword,String Day,String Month,String Year,String Fname,String Lname,String gender,String Country,String House,String Location) {
	
		driver.get(URL);
		Assert.assertEquals(driver.getCurrentUrl(), URL);
		JavascriptExecutor je = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 2000);
		driver.findElement(By.className("event_profile_register")).click();
		
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Assert.assertEquals(driver.getTitle(), "Crear perfil");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{
			
			Assert.assertEquals(driver.getTitle(), "Mein Profil erstellen");
		}
			
		else
			{
			Assert.assertEquals(driver.getTitle(), "Olay Club Offers, Samples and Exclusive Content");
		
		}
		
	/***********************/
		if(!URL.equals("https://www.olay.co.uk/en-gb") )
		{
			//Gender selection
			if(gender.equals("F"))
		driver.findElement(By.id("phdesktopbody_0_imgfemale")).click();
			else
		driver.findElement(By.id("phdesktopbody_0_imgmale")).click();
		//FirstName
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys(Fname);
		//LastName
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys(Lname);
		}
		//Email
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys(Email);
		if(!password.equals(ConPassword))
			Assert.fail("Password doesnot match with reconfirm password");
		//Password
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][password]']")).sendKeys(password);
		//Password re-confirm
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][confirm]']")).sendKeys(ConPassword);
				
		if(URL.equals("https://www.olaz.de/de-de"))
		{
			je.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$ctl72']")));
			//Birthday date
			Select day = new Select(driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$ctl72']")));
			day.selectByVisibleText(Day);
			//Birthday Month
			Select month = new Select(driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$ctl74']")));
			month.selectByVisibleText(Month);
			//Birthday year
			Select year = new Select(driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$ctl76']")));
			year.selectByVisibleText(Year);
			je.executeScript("window.scrollBy(0,100)");
			Select country = new Select(driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][country]\"]")));
			//Selection of country
			country.selectByValue(Country);
			//House address
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][line1]\"]")).sendKeys(House);
			//Address location
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][city]\"]")).sendKeys(Location);
			driver.findElement(By.id("phdesktopbody_0_ctl104")).click();
		}
		else
		{
			//Birthday date
			driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][day]']")).sendKeys(Day);
			//Birthday Month
			driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[birthdate][month]']")).sendKeys(Month);
			//Birthday year
			driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']")).sendKeys(Year);
		}
		
		//Register click
		WebElement date = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']"));
		je.executeScript("arguments[0].scrollIntoView();", date);
		date.click();
		WebElement error;
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type = 'submit']")));
		error = driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]errmsg"));
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Assert.assertEquals(error.getText(), "La contrase�a debe tener un m�nimo de 8 caracteres, incluyendo al menos 1 letra y 1 n�mero.");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{	
			Assert.assertEquals(error.getText(), "Ihr Kennwort muss mindestens 8 Zeichen lang sein und mindestens 1 Buchstaben sowie eine Zahl enthalten.");
		}
			
		else
			{
			Assert.assertEquals(error.getText(), "The password must be minimum 8 characters, including at least 1 letter and 1 number.");
			
		}
		System.out.println("Password is not upto expectation");
	}
	
}
