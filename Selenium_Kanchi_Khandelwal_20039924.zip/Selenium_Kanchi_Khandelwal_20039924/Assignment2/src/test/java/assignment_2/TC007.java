//Incorrect Password
package assignment_2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class TC007 extends Initialization {
	
	@DataProvider(name="Login_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ExcelReader.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment2\\src\\test\\resources\\Olay.xlsx" , "IncorrectPassword");
		return obj;
	};		
	
	@Test(dataProvider="Login_Details")
	public static void Registration(String URL,String Email,String password) {
	
		driver.get(URL);
		Assert.assertEquals(driver.getCurrentUrl(), URL);
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
		
		if(URL.equals("https://www.olay.es/es-es"))
		{
			Assert.assertEquals(driver.getTitle(), "Inicia sesi�n en tu cuenta");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{
			
			Assert.assertEquals(driver.getTitle(), "Anmelden");
		}
			
		else
			{
			Assert.assertEquals(driver.getTitle(), "Login");
		
		}
		//Email 
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_username']")).sendKeys(Email);
		//Password
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_password\"]")).sendKeys(password);
		//Sign In click
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		WebElement error = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_Message']"));
		boolean value;
		
	/***********************/
				//Register click
		if(URL.equals("https://www.olay.es/es-es"))
		{
			value = error.getText().contains("La combinaci�n de correo electr�nico y la contrase�a que has introducido es incorrecta.");
			Assert.assertTrue(value, "Incorrect password");
		}
		else if(URL.equals("https://www.olaz.de/de-de"))
		{	
			value = error.getText().contains("Die eingegebene Kombination aus Passwort und E-Mail-Adresse ist ung�ltig.");
			Assert.assertTrue(value, "Incorrect password");
		}	
		else
		{
			value = error.getText().contains("The email and password combination you entered is incorrect.");
			Assert.assertTrue(value, "Incorrect password");
		}
		System.out.println("password Incorrect");
	}
	
}
