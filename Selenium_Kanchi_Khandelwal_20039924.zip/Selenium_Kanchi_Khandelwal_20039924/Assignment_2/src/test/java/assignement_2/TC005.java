// Date entering is mandatory field 
package assignement_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC005 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.olay.co.uk/en-gb");
		JavascriptExecutor je = (JavascriptExecutor) driver;
		driver.findElement(By.className("event_profile_register")).click();
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys("Kaccncchiabcd1@gmail.com");
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][password]']")).sendKeys("qwerty@123");
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][confirm]']")).sendKeys("qwerty@123");
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[birthdate][month]']")).sendKeys("10");
		driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']")).sendKeys("2001");
		WebElement reg = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']"));
		je.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		reg.click();
		je.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		String error = driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][day]errmsg\"]")).getText();
		System.out.println(error);
	


	}

}
