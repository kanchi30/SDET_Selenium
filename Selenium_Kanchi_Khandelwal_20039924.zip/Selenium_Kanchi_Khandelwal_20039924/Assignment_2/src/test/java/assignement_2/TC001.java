package assignement_2;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC001 {
	static WebDriver driver;
@DataProvider(name = "Authentication")
public Object[][] DataProvide()
{	
	return new Object[][] {{"https://www.olay.co.uk/en-gb",UUID.randomUUID(),"kanchi123","kanchi123", "1" , "2" , "2000"},
		{"https://www.olay.co.uk/en-gb", UUID.randomUUID(),"kanchi123","kanchi12", "1" , "2" , "2000"},
		{"https://www.olay.co.uk/en-gb", UUID.randomUUID(),"kanchi254","kanchi254", "1" , "2" , "2002"}};
}

@Test(dataProvider ="Authentication")
	
	public void Test1(String URL , UUID random , String pass1 , String pass2 , String day , String month, String year) throws InterruptedException {
	WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(URL);
		JavascriptExecutor je = (JavascriptExecutor)driver;
		driver.findElement(By.className("event_profile_register")).click();
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys(random.toString() + "@gmail.com");
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][password]']")).sendKeys(pass1);
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][confirm]']")).sendKeys(pass2);
		driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][day]']")).sendKeys(day);
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[birthdate][month]']")).sendKeys(month);
		driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']")).sendKeys(year);
		WebElement date = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']"));
		je.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		date.click();
		Thread.sleep(1000);
		je.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_1_SiteLink\"]")).click();
		Thread.sleep(1000);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		if(driver.getTitle().equals("View Profile"))
			
			System.out.println("Account has been created");
		else
			{
			System.out.println("Account not created");
			}
		
		driver.close();
	}

}
