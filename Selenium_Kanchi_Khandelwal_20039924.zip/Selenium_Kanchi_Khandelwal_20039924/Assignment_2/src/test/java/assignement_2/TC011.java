package assignement_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC011 {
	
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.olay.co.uk/en-gb");
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[1]")).click();
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_username']")).sendKeys("kanchi1234@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_password\"]")).sendKeys("kanchi@95");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_SIGN IN\"]")).click();
		if(driver.getCurrentUrl().equals("https://www.olay.co.uk/en-gb/viewprofilepage"))
			System.out.println("Sign in is successfull");
	}
	

}
