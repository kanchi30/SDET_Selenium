package assignement_2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TC013 {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException, IOException, ParseException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		File src = new File("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_2\\src\\test\\resources\\Test.xlsx");
		FileInputStream fis = new FileInputStream(src);
		@SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh1 = wb.getSheet("Sheet1");
		for (int i = 1; i < (sh1.getLastRowNum() - sh1.getFirstRowNum()); i++) {
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get("https://www.olaz.de/de-de");
			JavascriptExecutor je = (JavascriptExecutor) driver;
			Row row = sh1.getRow(i);
			driver.findElement(By.className("event_profile_register")).click();
			driver.findElement(By.id("phdesktopbody_0_imgfemale")).click();
			System.out.println(row.getCell(1).toString());
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys(row.getCell(0).toString());
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys(row.getCell(1).toString());
			driver.findElement(
					By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]']"))
					.sendKeys(row.getCell(2).toString());
			driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][password]']"))
					.sendKeys(row.getCell(3).toString());
			driver.findElement(
					By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][confirm]']"))
					.sendKeys(row.getCell(4).toString());
			Select date = new Select(
					driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[6]/div[3]/select")));
			date.selectByValue(row.getCell(5).toString());
			Select month = new Select(
					driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[6]/div[4]/select")));
			month.selectByValue(row.getCell(6).toString());
			Select year = new Select(
					driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_Container\"]/div[6]/div[5]/select")));
			year.selectByValue(row.getCell(7).toString());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,100)");
			Select land = new Select(driver
					.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][country]\"]")));
			List<WebElement> list = land.getOptions();
			list.get(Integer.parseInt(row.getCell(8).toString())).click();
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][line1]\"]"))
					.sendKeys(row.getCell(9).toString());
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_labelgrs_account[addresses][0][city]\"]"))
					.sendKeys(row.getCell(10).toString());
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_ctl104\"]")).click();
			js.executeScript("window.scrollBy(0,100)");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]")).click();
			if (driver.getCurrentUrl().equals("https://www.olaz.de/de-de/loginpage/create-profile-thank-you-page"))
				System.out.println("account created");
			driver.close();
		}
	}
}
