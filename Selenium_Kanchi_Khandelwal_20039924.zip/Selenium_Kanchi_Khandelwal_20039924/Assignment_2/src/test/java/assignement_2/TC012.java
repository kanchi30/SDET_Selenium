package assignement_2;


import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC012 {
	
	public static void main (String[] args) throws InterruptedException, IOException, ParseException {
		WebDriverManager.chromedriver().setup();
		JSONParser jsonparser = new JSONParser();
		FileReader reader = new FileReader("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_2\\src\\test\\resources\\Test.JSON");
		Object userid = jsonparser.parse(reader);
		JSONArray usersList = (JSONArray) userid;

for(int i=0;i<usersList.size();i++) 
{
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

System.out.println(usersList.size());
System.out.println(usersList);
JSONObject user = (JSONObject) usersList.get(i);
System.out.println(user);
String URL = (String) user.get("URL");
String Fname  = (String) user.get("First");
String Lname = (String) user.get("Last");
String Email = (String) user.get("Email");
String pass = (String) user.get("Pass");
String Re = (String) user.get("Re");
String Day = (String) user.get("Day");
String Month = (String) user.get("Month");
String Year = (String) user.get("Year");

		driver.get(URL);
		JavascriptExecutor je = (JavascriptExecutor)driver;
		
		driver.findElement(By.className("event_profile_register")).click();
		driver.findElement(By.id("phdesktopbody_0_imgfemale")).click();
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys(Fname);
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys(Lname);
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys(Email);
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][password]']")).sendKeys(pass);
		driver.findElement(By.xpath("//input[@name = 'phdesktopbody_0$phdesktopbody_0_grs_account[password][confirm]']")).sendKeys(Re);
		driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][day]']")).sendKeys(Day);
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[birthdate][month]']")).sendKeys(Month);
		driver.findElement(By.xpath("//select[@name = 'phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']")).sendKeys(Year);
		WebElement sub = driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']"));
		je.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		sub.click();
		Thread.sleep(1000);
		if(driver.getCurrentUrl().equals("https://www.olay.es/es-es/loginpage/create-profile-thank-you-page"))
			System.out.println("Account has been created");
		else
			System.out.println("Account not created");
		driver.close();
	}
	}
}
