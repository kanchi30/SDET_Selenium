package assignment_1;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC004 {
	public static int currentDay;
	public static int currentMonth;
	public static int currentYear;
	public static int targetDay;
	public static int targetMonth;
	public static int targetYear;
	public static boolean jump = true;
	public static boolean jump1 = true;
	public static int jumpBymonth = 0;
	public static int jumpByYear=0;
	
	public static void getTarget(String date)
		{
			int firstIndex = date.indexOf('/');
			int lastIndex = date.lastIndexOf('/');
			targetDay =   Integer.parseInt(date.substring(0, firstIndex));
			targetMonth =   Integer.parseInt(date.substring(firstIndex+1,lastIndex));
			targetYear =   Integer.parseInt(date.substring(lastIndex+1, date.length()));
		};
	
		public static void jumpByYear()
		{
			if(targetYear > currentYear)
			{
				jumpByYear = (targetYear-currentYear)*12;
			}
			else
			{
				jumpByYear=(currentYear-targetYear)*12;
				jump1 = false;
			}
		}
		
	public static void jumpByMonth()
	{
		if(targetMonth> currentMonth)
		{
			jumpBymonth = targetMonth-currentMonth;
		}
		else
		{
			jumpBymonth=currentMonth-targetMonth;
			jump = false;
		}
		
	}
	
	
	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/datepicker/");
		String date  = "30/06/1996";
		getTarget(date);
		driver.findElement(By.id("datepicker")).click();
		Calendar cal = Calendar.getInstance();
		currentDay = cal.get(Calendar.DAY_OF_MONTH);
		currentMonth = cal.get(Calendar.MONTH)+1;
		currentYear= cal.get(Calendar.YEAR);
		int i =1;
		jumpByMonth();
		jumpByYear();
		if(jump==true)
		{
			if(jump1==true)
			{	
				System.out.println(jumpBymonth+jumpByYear);
				while(i<=jumpBymonth+jumpByYear)
			{	
				driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[2]")).click();
				i++;
			}
			}
			else
			{
				System.out.println(jumpByYear-jumpBymonth);
				while(i<=jumpByYear-jumpBymonth)
			{	
				driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[1]")).click();
				i++;
			}
			}		
		}
		else
		{
			if(jump1==true)
			{
				while(i<=jumpByYear-jumpBymonth)
			{
				driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[2]")).click();
				i++;
			}
			}
			else
			{
				while(i<=jumpByYear+jumpBymonth)
				{
					driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[1]")).click();
					i++;
				}	
			}
		}
		driver.findElement(By.xpath("//*[text()='"+targetDay +"']")).click();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}
}

	
	