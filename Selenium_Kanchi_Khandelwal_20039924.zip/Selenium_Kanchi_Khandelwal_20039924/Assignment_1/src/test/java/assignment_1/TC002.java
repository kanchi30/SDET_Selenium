package assignment_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class  TC002{

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/html-contact-form/");
		driver.findElement(By.xpath("//input[@class='firstname']")).sendKeys("Kanchi");
		driver.findElement(By.xpath("//input[@id='lname']")).sendKeys("Khandelwal");
		driver.findElement(By.xpath("//input[@name='country']")).sendKeys("India");
		driver.findElement(By.xpath("//textarea[@id = 'subject']")).sendKeys("Selenium");
		String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN); 
		driver.findElement(By.linkText("Google Link")).sendKeys(selectLinkOpeninNewTab);
		driver.findElement(By.linkText("Google Link is here")).sendKeys(selectLinkOpeninNewTab);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(10);
		driver.quit();
	}

}
