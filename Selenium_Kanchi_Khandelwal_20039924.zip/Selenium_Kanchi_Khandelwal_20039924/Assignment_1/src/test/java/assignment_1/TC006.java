package assignment_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC006 {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/controlgroup/");		
		driver.findElement(By.id("car-type-button")).click();
		driver.findElement(By.id("ui-id-5")).click();
		driver.findElement(By.xpath("//label[@for='transmission-standard']")).click();
		driver.findElement(By.xpath("//label[@for='insurance']")).click();
		driver.findElement(By.id("horizontal-spinner")).sendKeys("4");
		driver.findElement(By.xpath("//button[text()= 'Book Now!']")).click();
		Thread.sleep(100);
		driver.close();
	}

}
