package assignment_1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC005 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/selectmenu/");		
		WebDriverWait wait = new WebDriverWait(driver,30);
		String xpath =  "ui-id-";
		int i =1;
		while(i<=34)
		{
			
			if(i<=5)
			{	
				driver.findElement(By.id("speed-button")).click();
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id(xpath.concat(Integer.toString(i))))));
				driver.findElement(By.id(xpath.concat(Integer.toString(i)))).click();
				System.out.println(driver.findElement(By.xpath("//span[@id ='speed-button']/span[@class='ui-selectmenu-text']")).getText());
				Thread.sleep(100);
			}
			if(i>5&&i<=9)
			{
				driver.findElement(By.id("files-button")).click();
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id(xpath.concat(Integer.toString(i))))));
				driver.findElement(By.id(xpath.concat(Integer.toString(i)))).click();
				System.out.println(driver.findElement(By.xpath("//span[@id ='files-button']/span[@class='ui-selectmenu-text']")).getText());
				Thread.sleep(100);
			}
			if(i>9 &&i<=28)
			{	
				WebElement dropdown = driver.findElement(By.xpath("//*[@id='number-menu']")); 
				WebElement b = driver.findElement(By.xpath("//*[@id='number-button']"));     
				b.click(); 
				Thread.sleep(1000);      	
				List<WebElement> DropdownItems = dropdown.findElements(By.tagName("li"));      	     
				DropdownItems.get(i-8).click();      	 
				Thread.sleep(1000);      	
				String s = b.findElement(By.className("ui-selectmenu-text")).getText();      
				System.out.print(s);
			}
			if(i>29 &&i<=34)
			{
				driver.findElement(By.id("salutation-button")).click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(xpath.concat(Integer.toString(i)))));
				driver.findElement(By.id(xpath.concat(Integer.toString(i)))).click();
				Thread.sleep(100);
			}
			i++;
		}
								
		driver.close();
		
	}

}
