package assignment_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC001 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(2000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/selectable/");
		int i = 1;
		while(i<=7)
		{
		driver.findElement(By.xpath("//*[@id = 'selectable']/li[" +i + "]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id = 'selectable']/li[" +i + "]")).getText());
		i++;
		}
		driver.close();
	}

}
