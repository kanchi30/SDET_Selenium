package assignment_3;

import org.testng.annotations.Test;

import pageBase.Page;
import pages.ReviewPage;
import pages.SelectionPage;

import java.io.IOException;
import org.testng.annotations.DataProvider;

public class TC003 extends Initialization {

	@DataProvider(name = "Travel_Details")
	public Object[][] DataProvide() throws Exception {
		Object[][] obj = ReadExcel.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_3\\src\\test\\resources\\MakeMyTrip.xlsx", "MultiCity");
		return obj;
	}

	@Test(dataProvider = "Travel_Details" , testName="Multi_Way")
	public void MultiCity(String way , String Src,String Mid, String Dest, String date,String rtrn) throws InterruptedException, IOException {
		
		// Navigation to makeMyTrip
		Page.hold();
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");
		
		//MultiCity Selection
		
		SelectionPage selectPage = new SelectionPage();
		selectPage.tripSelection(way);
		
		//source selection
		selectPage.SourceSelection(Src);
		
		//Mid Selection
		Thread.sleep(1000);
		selectPage.DestinationSelection(Mid);
		
		//Selection of first departure date
		selectPage.TravelDate(date);
				
		//Selection of destination
		selectPage.MidSelection(Dest);
		
		//return date
		Thread.sleep(1000);
		selectPage.ReturnDate(rtrn);
		//search button
		Thread.sleep(1000);
		selectPage.searchButton();
		
		softassert.assertEquals(driver.getTitle(), "Makemytrip");
		
		//BookNow button		
		String price = selectPage.getPrice();
		Thread.sleep(1000);
		selectPage.bookButton();	
		ReviewPage review = new ReviewPage();
		System.out.println(price);
		review.Switch();
		  softassert.assertTrue(review.CityReview(Src));
		  softassert.assertTrue(review.CityReview(Dest));
		  softassert.assertTrue(review.CityReview(Dest));
		  softassert.assertAll();
		
	}

}
