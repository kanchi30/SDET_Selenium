package assignment_3;

import java.io.IOException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageBase.Page;
import pages.ReviewPage;
import pages.SelectionPage;
//@Listeners(ListenerTest.class)
public class TC001 extends Initialization {
	
	@DataProvider(name="Travel_Details")
	public Object[][] DataProvide() throws Exception
	{
		Object[][] obj  = ReadExcel.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_3\\src\\test\\resources\\MakeMyTrip.xlsx" , "OneWay");
		return obj;  
	};		
	
	@SuppressWarnings("unused")
	@Test(dataProvider ="Travel_Details", testName="one-Way")
	public void OneWay(String way ,String Src , String Dest , String date) throws InterruptedException, IOException {
		Page.hold();
		
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");		
		SelectionPage selectPage = new SelectionPage();
		//One way selection
		selectPage.tripSelection(way);
		
		//Source airport selection
		selectPage.SourceSelection(Src);
		
		//Destination airport selection
		Thread.sleep(1000);
		selectPage.DestinationSelection(Dest);
	
		//Selection of travel Date	
		selectPage.TravelDate(date);
		
		//click on search button
		Thread.sleep(1000);
		selectPage.searchButton();
		
	//	String price = selectPage.getPrice();
		selectPage.bookButton();	
		ReviewPage review = new ReviewPage();
		Thread.sleep(1000);
	//	System.out.println(price);
		review.Switch();
		  softassert.assertTrue(review.CityReview(Src));
		  softassert.assertTrue(review.CityReview(Dest));
		  softassert.assertAll();
		  
		}
	
}


