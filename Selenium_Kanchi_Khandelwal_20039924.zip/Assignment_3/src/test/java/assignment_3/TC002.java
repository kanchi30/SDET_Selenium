package assignment_3;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageBase.Page;
import pages.ReviewPage;
import pages.SelectionPage;
public class TC002 extends Initialization  {

	@DataProvider(name = "Travel_Details")
	public Object[][] DataProvide() throws Exception {
		Object[][] obj = ReadExcel.getTableArray("C:\\Users\\khand\\Desktop\\Selenium_Kanchi_Khandelwal_20039924\\Assignment_3\\src\\test\\resources\\MakeMyTrip.xlsx", "RoundTrip");
		return obj;
	};

	@Test(dataProvider = "Travel_Details" , testName="two Way")
	public void TwoWay(String way , String Src, String Dest, String date,String rtrn) throws InterruptedException, IOException {
		
		Page.hold();
		
		softassert.assertEquals(driver.getCurrentUrl(), "https://www.makemytrip.com/");		
		SelectionPage selectPage = new SelectionPage();
		// two way selection
		selectPage.tripSelection(way);
		
		// Source airport selection
		selectPage.tripSelection(way);
		
		// Destination airport selection
		Thread.sleep(1000);
		selectPage.DestinationSelection(Dest);
		
		// Selection of travel Date
		Thread.sleep(1000);
		selectPage.TravelDate(date);
		//Selection of return Date
		selectPage.ReturnDate(rtrn);
		
		// click on search button
		Thread.sleep(1000);
		selectPage.searchButton();
		
		softassert.assertEquals(driver.getTitle(), "Makemytrip");

		softassert.assertAll();
		
		//String price = selectPage.getPrice();
		selectPage.bookButton();	
		
		ReviewPage review = new ReviewPage();
		//System.out.println(price);
		review.Switch();
		  softassert.assertTrue(review.CityReview(Src));
		  softassert.assertTrue(review.CityReview(Dest));
		  softassert.assertAll();
				}

}
