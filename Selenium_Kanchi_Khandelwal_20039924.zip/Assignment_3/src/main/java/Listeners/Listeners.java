package Listeners;

import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.testng.ISuite;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import Utilities.ExtentManager;
import Utilities.testUtil;

public class Listeners extends pageBase.Page implements ITestListener {
	static String filepath = System.getProperty("user.dir") + System.getProperty("file.separator") + "screenshot";
	static String filepath_failed = System.getProperty("user.dir") + System.getProperty("file.separator") + "screenshot"
			+ System.getProperty("file.separator") + "Failed";
	static String filepath_skipped = System.getProperty("user.dir") + System.getProperty("file.separator")
			+ "screenshot" + System.getProperty("file.separator") + "Skipped";
	String path = "<a href  = \"" + filepath_failed + "\"> Screenshot Link</a>";

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	private static ExtentReports extent = ExtentManager.createInstance(System.getProperty("user.dir")+"/Reports/"+fileName);
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();

	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub

		log.info(result.getName().trim() + "Test Case Started");
		ExtentTest test = extent.createTest(result.getTestClass().getName()+"     @TestCase : "+result.getMethod().getMethodName());
        testReport.set(test);
        

	}

	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		/// if( ITestResult.SUCCESS )

		String methodName = result.getMethod().getMethodName();
		log.info(methodName + "Test Case Passed");
		String logText = "<b>" + "TEST CASE:- " + methodName.toUpperCase() + " PASSED" + "</b>";
		Markup m=MarkupHelper.createLabel(logText, ExtentColor.GREEN);
		testReport.get().pass(m);
		
		System.out.println("Test Case Passed --  " + result.getName());
	}

	public void onTestFailure(ITestResult result) {
		// if(result == ITestResult.FAILURE) {
		// TODO Auto-generated method stub
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		System.out.println("Test Case Failed -- " + result.getName());
		System.out.println("Capturing screenshot !");
		String method_name = result.getName().toString().trim();

		

		

		String exceptionMessage=Arrays.toString(result.getThrowable().getStackTrace());
		testReport.get().fail("<details>" + "<summary>" + "<b>" + "<font color=" + "red>" + "Exception Occured:Click to see"
				+ "</font>" + "</b >" + "</summary>" +exceptionMessage.replaceAll(",", "<br>")+"</details>"+" \n");
		
		try {

			testUtil.captureFailedScreenshot(method_name);;
			testReport.get().fail("<b>" + "<font color=" + "red>" + "Screenshot of failure" + "</font>" + "</b>",
					MediaEntityBuilder.createScreenCaptureFromPath(testUtil.mailFailedScreenshotPath)
							.build());
		} catch (IOException e) {
			e.printStackTrace();
		}

		


		String failureLogg = "TEST CASE FAILED";
		Markup m = MarkupHelper.createLabel(failureLogg, ExtentColor.RED);
		testReport.get().log(Status.FAIL, m);


		log.error(method_name + failureLogg);

		System.setProperty("org.uncommons.reportng.escape-output", "false");

		
		Reporter.log("<a href=\"" +  testUtil.mailFailedScreenshotPath
				+ "\"  target = \" _blank\"> Screenshot Link</a>");
		Reporter.log("<hr>");
		Reporter.log("<a href=\"" +testUtil.mailFailedScreenshotPath+ "\" target = \" _blank \" align = center > <img src=\"" + filepath_failed
				+ System.getProperty("file.separator") + method_name + "_" + year + "_" + date + "_" + (month + 1) + "_"
				+ day + "_" + min + "_" + sec + ".jpeg" + "\" target = \" _blank \" width = 200 height = 200 > </a>");
		Reporter.log("<hr>");
//
		System.out.println("Screenshot can be found here - " + filepath_failed);
		// }

	}

	@SuppressWarnings("unused")
	public void onTestSkipped(ITestResult result) {
		// if(result = ITestResult.SKIP) {
		// TODO Auto-generated method stub
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		String method_name = result.getName().toString().trim();
		log.info(method_name + "Test Case Skipped");
		String logText="<b>"+"Test Case:- "+ method_name+ " Skipped"+"</b>";		
		Markup m=MarkupHelper.createLabel(logText, ExtentColor.YELLOW);
		testReport.get().skip(m);

		System.out.println("Test Case Skipped -- " + result.getName());
		// System.out.println("Capturing screenshot !");
//		System.setProperty("org.uncommons.reportng.escape-output", "false");

//		Reporter.log("<a href  = \"" + filepath_skipped + System.getProperty("file.separator") + method_name + "_"
//				+ year + "_" + date + "_" + (month + 1) + "_" + day + "_" + min + "_" + sec + ".jpeg"
//				+ "\" align=center target = \"_blank \"> Screenshot Link</a>");
//		Reporter.log("<hr>");
//		Reporter.log("<a href = \"" + filepath_skipped + System.getProperty("file.separator") + method_name + "_" + year
///				+ "_" + date + "_" + (month + 1) + "_" + day + "_" + min + "_" + sec + ".jpeg"
//				+ "\" align = center >  <img src= \"" + filepath_skipped + System.getProperty("file.separator")
//				+ method_name + "_" + year + "_" + date + "_" + (month + 1) + "_" + day + "_" + min + "_" + sec
//				+ ".jpeg" + "\" target = \" _blank \" width = 200 height = 200 >   </a> ");
//		Reporter.log("<hr>");
//		WebDriver driver = (WebDriver) result.getTestContext().getAttribute("driver");
//		String methodName = result.getName().toString().trim();
//
//	try {
//		testUtil.captureSkippedScreenshot(methodName);
//		} catch (IOException e) {
		// TODO Auto-generated catch block
//		e.printStackTrace();
//		}

	
		//System.out.println("Screenshot can be found here - " + filepath_skipped);
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub

	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		if (extent != null) {

			extent.flush();
		}


	}

	public void onStart(ISuite suite) {
		// TODO Auto-generated method stub
		log.info("Suite Started" + suite.getName().trim());
	}

	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		// testUtil.zip(filepath);
		// AppZip appZip = new AppZip();
		// appZip.generateFileList(new File(AppZip.SOURCE_FOLDER));
		// appZip.zipIt(AppZip.OUTPUT_ZIP_FILE);
//
//		monitoringMail mail = new monitoringMail();
//		try {
//			mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject, TestConfig.messageBody,
//					TestConfig.attachmentPath, TestConfig.attachmentName);
//		} catch (AddressException e) {
//			// TODO Auto-generated catch block
///		e.printStackTrace();
		// } catch (MessagingException e) {
		// TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// System.out.println("On Finish ");

		log.info("Suite Finished" + suite.getName().trim());
	}

//	public boolean retry(ITestResult result) {
	// TODO Auto-generated method stub
//System.out.println("retry");
//		if (retrycount < maxretyrcount) {
//			System.out.println("Retrying test " + result.getName() + " with status "
//					+ getResultStatusName(result.getStatus()) + " for the " + (retrycount + 1) + " time(s).");
//			retrycount++;
//			return true;
//		}
//
//		return false;
//	}
//
//	public String getResultStatusName(int status) {
//		String resultName = null;
//		if (status == 1)
//			resultName = "SUCCESS";
//		if (status == 2)
//			resultName = "FAILURE";
//		if (status == 3)
//			resultName = "SKIP";
//		return resultName;

//	}

}
