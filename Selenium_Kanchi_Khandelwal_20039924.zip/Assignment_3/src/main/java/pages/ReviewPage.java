package pages;

import pageBase.Page;

public class ReviewPage extends Page {

	public void Switch() {
		System.out.println("Window switch");
		windowSwitch();
	}

	public boolean CityReview(String city) {
		return isElementPresent("CityText1_XPATH", "CityText2_XPATH", city);
	}
	
	
}

