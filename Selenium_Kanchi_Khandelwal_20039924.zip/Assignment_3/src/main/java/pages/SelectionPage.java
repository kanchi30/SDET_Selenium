package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class SelectionPage extends pageBase.Page {

	public static String Trip;
	public  void tripSelection(String way) throws InterruptedException
	{
		
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/ul/li[6]")).click();
		Thread.sleep(3000);
		System.out.println("in selection");
		if(way.equals("OneWay"))
		{
			click("OneWay_XPATH");	
			Trip = "Oneway";
		}
		else if(way.equalsIgnoreCase("Round"))
		{
			click("TwoWay_XPATH");
			Trip = "RoundTrip";
		}
		else if(way.equalsIgnoreCase("Multi"))
		{
			System.out.println("Multi");
			Thread.sleep(1000);
			click("Multi_XPATH");
			Trip = "MultiCity";
		}
	}
	
	/*
	 * public static boolean validation( attribute, value) { return
	 * getAttribute(attribute, value, "OneWay_XPATH");
	 * 
	 * }
	 */  
	
	public void SourceSelection(String src) throws InterruptedException
	{
		
		if(Trip.equalsIgnoreCase("MultiCity"))
		{
			Thread.sleep(1000);
			click("SourceClick1_XPATH");	
		}
		else
		{
		Thread.sleep(1000);
		click("SourceClick_XPATH");	
		}
		type("Sourcetype_XPATH" , src);
		SelectCity("SourceCity1_XPATH", "SourceCity2_XPATH", src);
		
	}
	
	public void DestinationSelection(String dest) throws InterruptedException
	{
		
		if(!Trip.equalsIgnoreCase("MultiCity"))
		click("DestinationClick_XPATH");
		Thread.sleep(1000);
		type("Destinationtype_XPATH" , dest);
		SelectCity("SourceCity1_XPATH" ,"SourceCity2_XPATH" , dest);
	}
	
	public void MidSelection(String Mid)
	{
		click("MidClick_XPATH");
		type("Midtype_XPATH" , Mid);
		SelectCity("SourceCity1_XPATH" ,"SourceCity2_XPATH" , Mid);
	}
	
	public void TravelDate(String date )
	{
		if(Trip.equalsIgnoreCase("OneWay"))
		{
			//click("Date_XPATH");	
		}
		
		driver.findElement(By.xpath("//div[contains(@aria-label,'"+date+"')]")).click();	
		
	}

	public void ReturnDate(String date )
	{
		if(Trip.equalsIgnoreCase("RoundTrip"))
		{
		WebElement retrn = driver.findElement(By.xpath("//div[contains(@aria-label,'" + date + "')]"));
		new Actions(driver).moveToElement(retrn).click().build().perform();		
		}
		 else if(Trip.equalsIgnoreCase("MultiCity"))
		{
			 elementscroll("Date1_XPATH" ,"Date2_XPATH",date);
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@aria-label,'"+date+"')]")));
			 driver.findElement(By.xpath("//div[contains(@aria-label,'"+date+"')]")).click();
		}
	}
	public void searchButton()
	{
		click("Search_XPATH");
	}

	public void bookButton() throws InterruptedException
	{
			if(Trip.equalsIgnoreCase("OneWay"))
			{
		  if(driver.findElements(By.xpath(OR.getProperty("BookButton1_XPATH"))).size()> 0 ) { 
			  click("BookButton1_XPATH");
			  }
		 Thread.sleep(1000);
		 if(driver.findElements(By.xpath(OR.getProperty("BookButton2_XPATH"))).size()> 0 ) 
			 click("BookButton2_XPATH");
			}
			else if(Trip.equalsIgnoreCase("RoundTrip"))
			{
				Elementwait("BookButton3_XPATH"); 
				click("BookButton3_XPATH");
				if(driver.findElements(By.xpath(OR.getProperty("BookButton4_XPATH"))).size()> 0 ) { 
					  click("BookButton4_XPATH");
			}
			}
			else if (Trip.equalsIgnoreCase("MultiCity"))
			{
				click("BookButton5_XPATH");
			}
	}
	
	public String getPrice()
	{
		Elementwait("ActualPrice_XPATH");
		return gettext("ActualPrice_XPATH");
	}
}