package pageBase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import Listeners.Listeners;


public class Page {

	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static WebDriverWait wait;
	public static JavascriptExecutor je;
	
	public Page() {

		try {
			fis = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/Properties/OR.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			OR.load(fis);
			log.debug("OR file loaded !!!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		

	}

	@SuppressWarnings("static-access")
	public void selectDriver(WebDriver driver)
	{		
		this.driver = driver;
		log.debug("Browser Selected");
	}
	
	public static void click(String locator) {
	//	System.out.println(OR.getProperty(locator));
		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_XPATH")) {
			//System.out.println("in xpath");
			driver.findElement(By.xpath(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_ID")) {
			driver.findElement(By.id(OR.getProperty(locator))).click();
		}
		log.debug("Clicking on an Element : " + locator);
		Listeners.testReport.get().log(Status.INFO, "Clicking on : " + locator);
	}

	public static void hold()
	{
		wait = new WebDriverWait(driver,100);
		
	}
	
	public static String gettext(String locator) {
		String text = null;
		if (locator.endsWith("_CSS")) {
			text = driver.findElement(By.cssSelector(OR.getProperty(locator))).getText();
		} else if (locator.endsWith("_XPATH")) {
			text = driver.findElement(By.xpath(OR.getProperty(locator))).getText();
		} else if (locator.endsWith("_ID")) {
			text = driver.findElement(By.id(OR.getProperty(locator))).getText();
		}
		log.debug("Getting text of an element :" + locator);
		 Listeners.testReport.get().log(Status.INFO, "Getting text of : " + locator);
		return text;

	}

	public static void type(String locator, String value) {

		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locator))).sendKeys(value);
		} else if (locator.endsWith("_XPATH")) {
			driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
		} else if (locator.endsWith("_ID")) {
			driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);
		}

		log.debug("Typing in an Element : " + locator + " entered value as : " + value);
		Listeners.testReport.get().log(Status.INFO, "Typing in : " + locator + " entered value as " + value);

	}
	public static void SelectCity(String locator1 , String locator2 , String City) {
		WebElement src = driver.findElement(By.xpath(OR.getProperty(locator1)+ City +OR.getProperty(locator2)));
		if (locator1.endsWith("_CSS")) {
			src = driver.findElement(By.cssSelector(OR.getProperty(locator1)));
		} else if (locator1.endsWith("_XPATH")) {
			System.out.println("in xpath src");
			src = driver.findElement(By.xpath(OR.getProperty(locator1)+ City +OR.getProperty(locator2)));
		} else if (locator1.endsWith("_ID")) {
			src = driver.findElement(By.id(OR.getProperty(locator1)));
		}
		//Page.wait.until(ExpectedConditions.elementToBeClickable(src));
		src.click();
		log.debug("Typing in an Element : " + locator1 + "selected City" + City);
		Listeners.testReport.get().log(Status.INFO, "Selected city : " + locator1 + " entered value as " + City);

	}
	
	public static boolean getAttribute(String attribute, String value , String locator) {
		String text=null;
		if (locator.endsWith("_CSS")) {
			text = driver.findElement(By.cssSelector(OR.getProperty(locator))).getAttribute(attribute);
		} else if (locator.endsWith("_XPATH")) {
			text = driver.findElement(By.xpath(OR.getProperty(locator))).getAttribute(attribute);
		} else if (locator.endsWith("_ID")) {
			text = driver.findElement(By.id(OR.getProperty(locator))).getAttribute(attribute);
		}
		
		log.debug("Validating Element:" + locator +"attribute"+ attribute + " actual attribute as : " + value);
		Listeners.testReport.get().log(Status.INFO, "Entered city : " + locator + " entered value as " + value);
		return (text.equals(value));
		

	}

	public void Elementwait(String locator)
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OR.getProperty(locator))));
		log.debug("Element is present : " + locator);
	}
	
	public static void windowSwitch()
	{
		Set<String> windID = driver.getWindowHandles(); Iterator<String> itr =
				  windID.iterator();
				  
		@SuppressWarnings("unused") String windID1 = itr.next(); String windID2 =
		itr.next(); driver.switchTo().window(windID2);		
		log.debug("Switched to new Window");
		Listeners.testReport.get().log(Status.INFO, "Switched Window to new window");
	}
	
	public boolean isElementPresent(String locator1 , String locator2 , String value) {

		try {

			driver.findElement(By.xpath(OR.getProperty(locator1)+value+OR.getProperty(locator2)));
			return true;

		} catch (NoSuchElementException e) {

			return false;

		}
	}
	public void elementscroll(String locator1 , String locator2 , String value)
	{
		je = (JavascriptExecutor) driver;
		WebElement retrn = null;
		if (locator1.endsWith("_CSS")) {
			retrn = driver.findElement(By.cssSelector(OR.getProperty(locator1)+value + OR.getProperty(locator2)));
		} else if (locator1.endsWith("_XPATH")) {
			retrn = driver.findElement(By.xpath(OR.getProperty(locator1)+value + OR.getProperty(locator2)));
		} else if (locator1.endsWith("_ID")) {
			retrn = driver.findElement(By.id(OR.getProperty(locator1)+value + OR.getProperty(locator2)));
		}
		je.executeScript("arguments[0].scrollIntoView(true);", retrn );
		log.info("scrolling to locate element");
	}
	
}