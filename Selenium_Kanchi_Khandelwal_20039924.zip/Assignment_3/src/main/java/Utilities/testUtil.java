package Utilities;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import pageBase.Page;

public class testUtil extends Page {

	public static String mailFailedScreenshotPath;
	public static String mailSkippedScreenshotPath;
	public static String ScreenshotPath;
	public static String screenshotName;

	public static void captureScreenshot() throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		
		screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpeg";
		 try {
			 
		ScreenshotPath = System.getProperty("user.dir") + System.getProperty("file.separator")+"screenshots" +System.getProperty("file.separator") +screenshotName;
		FileUtils.copyFile(scrFile,	new File(ScreenshotPath));
		 } catch (IOException e) {
			 
			 e.printStackTrace();
		 }
		 
	}

	
	public static void captureFailedScreenshot(String methodName) throws IOException{
		
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);
		
		
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    try {
	    	mailFailedScreenshotPath = System.getProperty("user.dir")+System.getProperty("file.separator") + "screenshot"+ System.getProperty("file.separator")+"Failed"+System.getProperty("file.separator")+ methodName+"_"+year+"_"+date+"_"+(month+1)+"_"+day+"_"+min+"_" +sec+".jpeg";
			FileUtils.copyFile(scrFile, new File(mailFailedScreenshotPath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
				
	}
	
	}
	

	public static void captureSkippedScreenshot(String methodName) throws IOException{
		
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);
		
		
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    try {
	    	mailSkippedScreenshotPath = System.getProperty("user.dir")+System.getProperty("file.separator") + "screenshot"+ System.getProperty("file.separator")+"Skipped"+System.getProperty("file.separator")+ methodName+"_"+year+"_"+date+"_"+(month+1)+"_"+day+"_"+min+"_" +sec+".jpeg";
			FileUtils.copyFile(scrFile, new File(mailSkippedScreenshotPath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
		
	}
	
}
